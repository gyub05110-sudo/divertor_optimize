set -eu
p=/mnt/d/DivertorOptimization/studies/firefly-baseline-20261105
mnt=/mnt/firefly20261105
mkdir -p "$mnt"
mountpoint -q "$mnt" || mount -o loop "$p/runtime.ext4" "$mnt"
r="$mnt/bundle/rootfs"
mkdir -p "$r/work"
mountpoint -q "$r/work" || mount --bind "$p" "$r/work"
for name in dev proc sys; do mountpoint -q "$r/$name" || mount --bind "/$name" "$r/$name"; done
cd "$r"
chroot "$r" /usr/bin/env PATH=/usr/local/bin:/usr/bin:/bin LD_LIBRARY_PATH=/usr/local/lib PYTHONPATH=/usr/local/lib/python:/work/install/lib/python OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 OMPI_ALLOW_RUN_AS_ROOT=1 OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1 /bin/bash "/work/$1" "${@:2}"
