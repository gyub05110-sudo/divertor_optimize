set -eu
cd /work
# F2PY 2.2.4 leaks a procedure-local USE into its generated array wrapper.
# Remove only the redundant unrestricted import in the generated procedure.
sed -i '/subroutine f2pywrap_geometry_set_material_index (/,/end subroutine f2pywrap_geometry_set_material_index/{/^[[:space:]]*use firefly_geometry[[:space:]]*$/d;}' /tmp/firefly-build/src/python/f2py-f2pywrappers2.f90
cmake --build /tmp/firefly-build -j8
cmake --install /tmp/firefly-build
LD_LIBRARY_PATH=/work/install/lib:$LD_LIBRARY_PATH python3 -c 'from firefly.geometry import init_workspace;print(init_workspace)'
