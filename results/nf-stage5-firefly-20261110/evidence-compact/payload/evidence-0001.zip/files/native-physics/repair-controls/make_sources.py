from pathlib import Path
import sys
root=Path(__file__).resolve().parent
old=root.parent/"firefly-baseline-20261105/firefly/src/fortran/tasks.f90"
full=old.read_text()
prefix, body=full.split("  subroutine heat_load_proxy(",1)
body, tail=body.split("  end subroutine heat_load_proxy",1)
variant=sys.argv[1]
def replace(a,b):
    global body
    assert ("\n"+a) in body, a
    assert body.count("\n"+a)==1, (a,body.count("\n"+a))
    body=body.replace("\n"+a,"\n"+b)
if variant in ("diagnostic", "detail"):
    replace("  real(real64) :: psrc(3)", """  real(real64) :: qbefore(2), qafter(2), ds_before
  integer :: n_cross, nr_before, nwall_above, ibef
  real(real64) :: psrc(3)""")
    replace("  do i=1+rank,nparticles,nproc", """  n_cross=0
  nwall_above=0
  do i=1+rank,nparticles,nproc""")
    replace("        call tracing%xstep(c, dx, istat, n, u)", """        qbefore=mesh%rzcoords(c%mcoords)
        ibef=c%itube
        call tracing%xstep(c, dx, istat, n, u)
        qafter=mesh%rzcoords(c%mcoords)
        if (qbefore(2)<=zsrc(1)+1.d-9 .and. qafter(2)>zsrc(1)+1.d-9 .and. istat==0) then
           n_cross=n_cross+1
           if (n_cross<=20) print *, "CAP_DIAG X ", rank,i,nstep,istat,n,ibef,c%itube,qbefore,qafter
        endif""")
    replace("           call tracing%bstep(c, ds, istat, n, u)", """           qbefore=mesh%rzcoords(c%mcoords)
           ds_before=ds
           nr_before=istat
           ibef=c%itube
           call tracing%bstep(c, ds, istat, n, u)
           qafter=mesh%rzcoords(c%mcoords)
           if (qbefore(2)<=zsrc(1)+1.d-9 .and. qafter(2)>zsrc(1)+1.d-9) then
              n_cross=n_cross+1
              if (n_cross<=20) print *, "CAP_DIAG B ",rank,i,nstep,nreflect,nr_before,istat,n,ibef,c%itube, &
                    qbefore,qafter,c%p,ds_before,ds
           endif""")
    replace("              call S%boundary_event(w, pload_, wload)", """              if (c%p(2)>zsrc(1)+1.d-6) then
                 nwall_above=nwall_above+1
                 if (nwall_above<=5) print *, "CAP_DIAG WALL ", rank,i,nstep,n,istat,nreflect,c%p,qbefore,qafter,u
              endif
              call S%boundary_event(w, pload_, wload)""")
    replace("  call finalize_progress_bar()", """  print *, "CAP_DIAG TOTAL ",rank,n_cross,nwall_above
  call finalize_progress_bar()""")
    if variant=="detail":
        replace("        qafter=mesh%rzcoords(c%mcoords)\n        if (qbefore", """        qafter=mesh%rzcoords(c%mcoords)
        if (i==763 .and. nstep>=376418 .and. nstep<=376422) print *, "DETAIL X ",i,nstep,istat,n, &
                   ibef,c%itube,qbefore,qafter,c%p
        if (qbefore""")
        replace("           qafter=mesh%rzcoords(c%mcoords)\n           if (qbefore", """           qafter=mesh%rzcoords(c%mcoords)
           if (i==763 .and. nstep>=376418 .and. nstep<=376422) then
              print *, "DETAIL B ",nstep,nreflect,nr_before,istat,n,ibef,c%itube,ds_before,ds,qbefore,qafter,c%p,c%xi,c%t
              flush(output_unit)
              if (nstep==376422 .and. nreflect==3) error stop "diagnostic first bypass reproduced"
           endif
           if (qbefore""")
elif variant=="synchronized":
    replace("           c%xi(2) = -0.9999876543210d0",
            """           c%xi(2) = -0.9999876543210d0
           ! Keep the tracked physical point on the same magnetic coordinate after the inner-boundary clamp.
           ! A stale Cartesian point can put a nominal midplane impact on the opposite side of the cut.
           if (cap_index>0 .and. tracing%boundary_flag(c%itube)==1) c%p=mesh%rzphicoords(c%mcoords)""")
elif variant!="control":
    raise ValueError(variant)
new=root/variant;new.mkdir(exist_ok=True)
(new/"tasks.f90").write_text(prefix+"  subroutine heat_load_proxy("+body+"  end subroutine heat_load_proxy"+tail,newline="\n")
