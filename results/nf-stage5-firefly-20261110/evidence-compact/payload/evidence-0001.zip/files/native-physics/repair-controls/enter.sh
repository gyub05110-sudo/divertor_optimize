#!/bin/bash
set -eu
scratch=/mnt/d/DivertorOptimization/studies/nf-stage5-firefly-cap-repair-20261110
repo=/mnt/d/DivertorOptimization/worktrees/d3d-report-correction-20261104/verification
study=/mnt/d/DivertorOptimization/studies/nf-stage5-firefly-20261110
bash "$repo/stage5_native_enter.sh" "$study" "$repo" true
r=/mnt/firefly20261105/bundle/rootfs
exec 9>/run/lock/nf-stage5-scratch.lock
flock 9
mkdir -p "$r/repair"
mountpoint -q "$r/repair" || mount --bind "$scratch" "$r/repair"
test "$scratch" -ef "$r/repair"
flock -u 9
exec 9>&-
exec bash "$repo/stage5_native_enter.sh" "$study" "$repo" "$@"
