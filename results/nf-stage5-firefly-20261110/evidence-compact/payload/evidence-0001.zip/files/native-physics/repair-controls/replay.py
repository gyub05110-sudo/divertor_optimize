import ctypes
from pathlib import Path
from firefly import geometry
from mpi4py import MPI
base=Path("/stage5/native/cases/3264fdd71f")
geometry.init_workspace(str(base/"mesh/mmesh.nc"), seed=51031)
geometry.set_pfc(str(base/"021606f6597e71819ae87d1a57605978aae101e680c5a4c7e84de77b2a153318.pfc.nc"), dphi=2.,dl=.002)
if MPI.COMM_WORLD.rank==0:
    lib=ctypes.CDLL("/repair/replay.so")
    lib.replay_clamp.argtypes=[ctypes.c_int]
    lib.replay_clamp.restype=None
    lib.replay_clamp(0)
    lib.replay_clamp(1)
