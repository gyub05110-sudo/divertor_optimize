#!/bin/bash
set -eu
variant=$1; case=$2; wall=$3; seed=$4
export LD_LIBRARY_PATH=/repair/$variant:/work/install/lib:/usr/local/lib
mpirun --allow-run-as-root --oversubscribe --bind-to none -np 4 python3 /repair/native.py "$@"
