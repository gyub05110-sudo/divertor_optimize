"""Evaluate the synchronized historical and Stage 5 controls directly from native cell tallies."""
import hashlib
import json
from pathlib import Path
import sys
import h5py
import numpy as np
root=Path(__file__).resolve().parent
tree=Path("D:/DivertorOptimization/worktrees/d3d-report-correction-20261104")
sys.path.insert(0,str(tree))
from verification.stage5_native import STUDY, HISTORICAL, audit_tally, digest, read
from verification import stage5_metrics as met

def upper(path):
    with h5py.File(path) as f:
        geom=f["grid/domain/wall"]
        p=geom["x"][:,0,:]; z=f["grid/domain/reflect_midplane/x"][0,0,1]
        nphi=len(geom["domain/u"])-1;n=(len(p)-1)*nphi
        w=(f["hload"][:n]*f["area"][:n]).reshape(-1,nphi).sum(axis=1)*64e6
        return dict(z_cut_m=float(z), fully_upper_W=float(w[np.minimum(p[:-1,1],p[1:,1])>z+1e-9].sum()),
                    straddling_cells_W=float(w[(p[:-1,1]-z)*(p[1:,1]-z)<=0].sum()))

case="3264fdd71f"; seed=51031
positive_old=HISTORICAL/"blind_screen/results/ref_OMP_32027.nc"
positive=root/"synchronized/historical_ref_32027/native.nc"
rebuilt=root/"control/historical_ref_32027/native.nc"
assert digest(rebuilt)==digest(positive_old)
origin_wall=np.loadtxt(HISTORICAL/"blind_screen/walls/ref.wall")
original_tally=audit_tally(positive_old,origin_wall,1024)
corrected_tally=audit_tally(positive,origin_wall,1024)
assert corrected_tally["wall_above_midplane_W"] == 0
def cells(path):
    with h5py.File(path) as f:
        p=f["grid/domain/wall/x"][:,0,:]
        return p,f["hload"][:]*f["area"][:]*64e6
p,w0=cells(positive_old)
p1,w1=cells(positive)
assert np.array_equal(p,p1)
area=np.pi*np.linalg.norm(np.diff(p,axis=0),axis=1)*(p[1:,0]+p[:-1,0])
native_peaks=[float(np.max(w[:len(area)*3].reshape(-1,3).sum(axis=1)/area/1e6)) for w in (w0,w1)]
rows=[]
for role in read(STUDY/"inputs"/case/"case.json")["roles"][:2]:
    wall=role["wall_id"]
    reference=np.loadtxt(STUDY/"inputs"/case/"walls"/(wall+".wall"))
    grid,_,_=met.read_model(role,reference,1e6)
    old=STUDY/"native/results"/case/wall/"attempts"/str(seed)/"001/native.nc"
    new=root/"synchronized"/(case+"_"+wall[:10]+"_"+str(seed))/"native.nc"
    samples=[]
    for name,path in [("original",old),("synchronized",new)]:
        q=audit_tally(path,reference,4096)
        nodes,w,_=met.read_native(path,1e6); bank=met.project(nodes,w,grid)
        summary=met.summary(bank,grid)
        samples.append((bank,dict(variant=name, raw_sha256=digest(path),**q,**upper(path),
                                  peak_MW_m2=summary["peak_MW_m2"],A2_m2=summary["A2_m2"],
                                  peak_RZ_m=summary["peak_RZ_m"],peak_surface=summary["peak_surface"])))
    assert samples[0][1]["fully_upper_W"]>36
    assert samples[1][1]["fully_upper_W"]==samples[1][1]["wall_above_midplane_W"]==0
    rows.append(dict(case_id=case,wall_id=wall,role=role["role"],seed=seed,
                    half_integrated_abs_profile_change_W=float(np.abs(samples[1][0]-samples[0][0]).sum()*.5),
                    results=[s[1] for s in samples]))
res=dict(original_library_sha256=digest(HISTORICAL/"install/lib/libFIREFLY.so"),
         synchronized_library_sha256=digest(root/"synchronized/libFIREFLY.so"),
         historical_positive_F=dict(archived_raw_sha256=digest(positive_old),rebuilt_unmodified_sha256=digest(rebuilt),
                                    corrected_raw_sha256=digest(positive),original_ledger=original_tally,
                                    corrected_ledger=corrected_tally,half_abs_native_cell_difference_W=float(np.abs(w1-w0).sum()*.5),
                                    native_ring_peak_old_new_MW_m2=native_peaks),
         prospective_negative_F=rows)
(root/"control-results.json").write_text(json.dumps(res,indent=2)+"\n")
print(json.dumps(res,indent=2))
