from pathlib import Path
from firefly import geometry, tasks
import os,sys,json,time,resource
from mpi4py import MPI
b=Path("/stage5"); o=Path("/work"); variant, case, wall,seed=sys.argv[1:]; seed=int(seed)
start=time.monotonic()
if case=="historical":
    mesh=o/"blind_screen/mesh/mmesh.nc";target=o/"blind_screen/pfc/ref.nc";source=o/"OMP.source";n=1024
else:
    mesh=b/"native/cases"/case/"mesh/mmesh.nc";target=mesh.parent.parent/(wall+".pfc.nc");source=b/"inputs"/case/"OMP.source";n=4096
dest=Path("/repair")/variant/(case+"_"+wall[:10]+"_"+str(seed));dest.mkdir(exist_ok=True);os.chdir(dest)
comm=MPI.COMM_WORLD;assert comm.size==4
libs={line.split()[-1] for line in Path("/proc/self/maps").read_text().splitlines() if "libFIREFLY.so" in line}
assert libs=={"/repair/"+variant+"/libFIREFLY.so"},libs
geometry.init_workspace(str(mesh),seed=seed);geometry.set_pfc(str(target),dphi=2,dl=.002)
os.environ["FIREFLY_MIDPLANE_SOURCE"]=str(source)
os.environ["FIREFLY_HISTORY_SECONDS"]="0.2"
tau=4/(2*(2000/1.602176634e-19*100**2.5/1e19))
tasks.heat_load_proxy(1e19,100.,.45,n,pload=-1.,tau=tau,output=str(dest/"native.nc"))
comm.Barrier()
cpu=comm.gather(resource.getrusage(resource.RUSAGE_SELF).ru_utime,root=0)
if comm.rank==0:
  (dest/"timing.json").write_text(json.dumps(dict(seconds=time.monotonic()-start,cpu_seconds=sum(cpu),library=list(libs))))
