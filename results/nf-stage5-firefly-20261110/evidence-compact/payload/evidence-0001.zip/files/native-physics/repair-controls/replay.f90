subroutine replay_clamp(synchronized) bind(c)
  use iso_fortran_env, only: real64
  use iso_c_binding, only: c_int
  use firefly_geometry, only: mesh, tracing
  use flare_mmesh_unstructured_tracing, only: mcoords_workspace
  implicit none
  integer(c_int), value :: synchronized
  type(mcoords_workspace) :: c
  integer :: stat,n,k
  real(real64) :: ds,u(2),q(2),cut
  cut=1.6885746270418167d-2
  c%itube=492
  c%iphi=0
  c%t=0.26229251548574140d0
  c%xi=[0.77134596259216803d0,-0.99998765432100001d0]
  c%p=[1.1842896335585216d0,1.6514983348089141d-2,-4.5868571775849923d-2]
  q=mesh%rzcoords(c%mcoords)
  if (norm2(q-[1.1842896230460016d0,1.6514983798382440d-2])>1d-12) error stop "state replay mismatch"
  if (synchronized/=0) c%p=mesh%rzphicoords(c%mcoords)
  ds=3.4180069540992073d0
  stat=0
  do k=1,5
     call tracing%bstep(c,ds,stat,n,u)
     q=mesh%rzcoords(c%mcoords)
     print *, "step",synchronized,k,stat,n,ds,q
     if (stat==0) exit
     if (n/=2) error stop "expected reflecting boundary"
     ds=-ds
  enddo
  if (synchronized==0 .and. abs(q(2)-.65456047557023367d0)>1d-8) error stop "failed to reproduce original crossing"
  if (synchronized/=0 .and. (k/=2 .or. q(2)>=cut)) error stop "corrected step did not reflect exactly once"
end subroutine
