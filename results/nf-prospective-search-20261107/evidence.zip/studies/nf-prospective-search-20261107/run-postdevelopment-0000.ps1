# Run the registered continuation only after the full development parent records a successful qualified decision.
$env:PYTHONPATH='D:/DivertorOptimization/worktrees/d3d-report-correction-20261104/.local_dependencies/d3d-fixed-equilibrium'; $env:DIVERTOR_GPU_RUNTIME='D:/DivertorOptimization/runtime/cupy'; $env:TEMP='D:/DivertorOptimization/tmp'; $env:TMP=$env:TEMP; $env:PYTHONDONTWRITEBYTECODE='1'; $env:PYTHONIOENCODING='utf-8'; $env:OPENBLAS_NUM_THREADS='1'; $env:OMP_NUM_THREADS='1'; $env:MKL_NUM_THREADS='1'; $env:HF_HOME='D:/DivertorOptimization/cache/huggingface'; $env:CUPY_CACHE_DIR='D:/DivertorOptimization/cache/cupy'; $env:CUDA_CACHE_PATH='D:/DivertorOptimization/cache/cuda'; $env:MPLCONFIGDIR='D:/DivertorOptimization/cache/matplotlib';

$taskRepo = 'D:/DivertorOptimization/worktrees/d3d-report-correction-20261104'
$taskStudy = 'D:/DivertorOptimization/studies/nf-prospective-search-20261107'
$taskOutput = Join-Path $taskRepo 'results/nf-prospective-search-20261107'
$taskPython = 'C:/Users/FPL-user/miniforge3/python.exe'
Set-Location -LiteralPath $taskRepo
$devReceipt = Join-Path $taskStudy 'development-parent-0000.json'
while (-not (Test-Path -LiteralPath $devReceipt)) { Start-Sleep -Seconds 15 }
$dev = Get-Content -LiteralPath $devReceipt -Raw | ConvertFrom-Json
if ($dev.returncode -ne 0 -or $dev.log_sha256 -ne (Get-FileHash -LiteralPath (Join-Path $taskStudy 'development-parent-0000.log')).Hash.ToLowerInvariant()) { throw 'Development parent failed or log differs' }
$choice = Get-Content -LiteralPath (Join-Path $taskStudy 'development-choice.json') -Raw | ConvertFrom-Json
if (-not $choice.qualified) { Write-Output 'DEVELOPMENT REQUIRES REVIEW'; exit 3 }
function Invoke-StudyStage {
    param([string]$StageName, [string[]]$PythonArguments, [int[]]$AllowedExit = @(0))
    $stageLog = Join-Path $taskStudy ($StageName + '-parent-0000.log')
    $stageReceipt = Join-Path $taskStudy ($StageName + '-parent-0000.json')
    if ((Test-Path -LiteralPath $stageLog) -or (Test-Path -LiteralPath $stageReceipt)) { throw ('Stage evidence already exists: ' + $StageName) }
    Write-Output ('PARENT START ' + $StageName)
    $stageUtc = [DateTimeOffset]::UtcNow
    $stageClock = [Diagnostics.Stopwatch]::StartNew()
    & $taskPython -B -u @PythonArguments 2>&1 | Tee-Object -FilePath $stageLog
    $stageRc = $LASTEXITCODE
    $stageClock.Stop()
    [ordered]@{start_utc=$stageUtc.ToString('o'); end_utc=[DateTimeOffset]::UtcNow.ToString('o'); elapsed_s=$stageClock.Elapsed.TotalSeconds; returncode=$stageRc; arguments=$PythonArguments; log_sha256=(Get-FileHash -LiteralPath $stageLog -Algorithm SHA256).Hash.ToLowerInvariant()} | ConvertTo-Json | Set-Content -LiteralPath $stageReceipt -Encoding utf8
    if ($stageRc -notin $AllowedExit) { throw ('Stage failed: ' + $StageName + ' exit ' + $stageRc) }
    Write-Output ('PARENT FINISH ' + $StageName + ' exit ' + $stageRc)
}
Invoke-StudyStage -StageName freeze-holdout -PythonArguments @('-m','verification.nf_prospective_campaign','--study',$taskStudy,'--action','freeze-holdout')
Invoke-StudyStage -StageName holdout -PythonArguments @('-m','verification.nf_prospective_campaign','--study',$taskStudy,'--action','holdout')
Invoke-StudyStage -StageName audit -PythonArguments @('-m','verification.nf_prospective_campaign','--study',$taskStudy,'--action','audit')
Invoke-StudyStage -StageName numerics-lock -PythonArguments @('-m','verification.nf_prospective_numerics','--study',$taskStudy,'--lock-only')
Invoke-StudyStage -StageName numerics-score -PythonArguments @('-m','verification.nf_prospective_numerics','--study',$taskStudy,'--score') -AllowedExit @(0,2)
if (-not (Test-Path -LiteralPath (Join-Path $taskStudy 'numerics/summary.json'))) { throw 'Inspect open numerical evidence' }
Invoke-StudyStage -StageName report -PythonArguments @('-m','verification.nf_prospective_report','--study',$taskStudy,'--output',$taskOutput)

