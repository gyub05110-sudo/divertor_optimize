"""Independent, standard-library replay of published scores for the closed study."""
import argparse
import hashlib
import json
import math
from collections import Counter
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def check(study, report):
    frozen, publication = read(study/"frozen.json"), read(report)
    declared = {(p["case_id"], p["seed"], p["cutoff_s"]): p for p in publication["live"]["pairs"]}
    numerical = {(c["case_id"], p["seed"], p["cutoff_s"]): p for c in publication["numerical"]["cases"] for p in c["pairs"]}
    facts = {}
    ends, native, settings, late, statuses = 0, 0, 0, 0, Counter()
    expected_seeds = (20711, 20729, 20747)
    assert len(frozen["jobs"])==18 and tuple(frozen["seeds"])==expected_seeds
    for job in frozen["jobs"]:
        folder = study/job["relative_dir"]
        proc, record = read(folder/"process.json"), read(folder/"result.json")
        assert digest(folder/"events.jsonl")==proc["events_sha256"] and digest(folder/"result.json")==proc["result_sha256"]
        raw=[json.loads(line) for line in (folder/"events.jsonl").read_bytes().splitlines() if line]
        assert raw==record["events"]
        statuses[record["stop"]]+=1
        late +=sum(e["stage"] in ("fine","coarse") and e["end_s"]>job["budget_s"] for e in raw)
        for t in ((200,400,600,1800) if job["budget_s"]==1800 else (200,400,600)):
            key=job["case_id"],job["seed"],t
            arm="fast" if job["policy"]=="coarse_adaptive" else "direct"
            reported=declared[key][arm]
            pool=[e for e in raw if e["status"]=="completed" and e["end_s"]<=t and e["stage"] in ("baseline","fine")
                  and not e.get("cached") and e["measurement"]["eligible"]]
            if record["stop"]=="failed":
                assert not pool and not reported["available"] and reported["peak"] is None
                facts.setdefault(key,{})[arm]=None
            else:
                best=min(pool,key=lambda x:x["measurement"]["peak"]) if pool else None
                assert bool(best)==reported["available"]
                if best:
                    state=best["measurement"]
                    identity="original_wall" if best["stage"]=="baseline" else best["id"]
                    assert (state["peak"],state["A2"],identity)==(reported["peak"],reported["A2"],reported["selected_id"])
                    ledger=state["ledger"]
                    assert ledger==reported["selected_ledger"]
                    assert math.isclose(abs(ledger["deposited"]+ledger["unhit"]-ledger["prescribed"])/ledger["prescribed"],
                                        reported["power_relative_error"],abs_tol=1e-15)
                    facts.setdefault(key,{})[arm]=(identity,state["peak"],state["A2"])
                else:
                    facts.setdefault(key,{})[arm]=None
            ends+=1
    for key, arms in facts.items():
        expect=declared[key]
        a,b=arms["fast"],arms["direct"]
        assert expect["available"]==bool(a and b)
        if not a or not b:
            continue
        G=100*(1-a[1]/b[1])
        assert math.isclose(G,expect["margin"]["gap_pct"],abs_tol=1e-12)
        native+=1
        if key not in numerical:
            continue
        domain=numerical[key]
        gaps=[]
        for resolution in ("cubic640","cubic1280","quintic640","quintic1280"):
            vals=[read(study/"numerics"/key[0]/"scores"/f"{cell[0]}.{resolution}.json")["measurement"] for cell in (a,b)]
            if all(m["eligible"] for m in vals):
                gap=100*(1-vals[0]["peak"]/vals[1]["peak"])
                gaps.append(gap)
                if resolution=="cubic1280":
                    for latest,cell in zip(vals,(a,b)):
                        assert math.isclose(latest["peak"],cell[1],rel_tol=1e-10) and math.isclose(latest["A2"],cell[2],rel_tol=1e-10)
                settings+=1
        if gaps:
            assert all(math.isclose(x,y,abs_tol=1e-12) for x,y in zip([min(gaps),max(gaps)],domain["eligible_gap_range_pct"],strict=True))
    assert len(facts)==30 and len(numerical)==12
    return dict(arm_cutoffs_checked=ends,paired_cutoffs_checked=len(facts),comparable_paired_cutoffs=native,
                registered_posttrial_pairs=len(numerical),eligible_paired_setting_checks=settings,
                after_final_deadline_score_events_preserved=late,arm_stop_counts=dict(statuses),
                frozen_sha256=digest(study/"frozen.json"),report_sha256=digest(report),status="verified")


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study",type=Path,required=True)
    parser.add_argument("--summary",type=Path,required=True)
    args=parser.parse_args()
    print(json.dumps(check(args.study,args.summary),indent=2))

