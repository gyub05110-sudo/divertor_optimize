# 신규 DIII-D 평형 입력의 출처와 재현

Sophelio와 General Atomics의 *The Fusion Equilibrium Challenge: Predicting Plasma Shape from Control Inputs*에서 공개한 DIII-D 학습 원자료를 사용했다. 원본 parquet 바이트를 복사했고 익명 식별자와 EFIT 시각을 기록했다. 고정 revision은 `1e280905b85f2a6fdde7e06fca8cf3a1edf447cb`이다. 원자료 저자와 DOE 지원 정보는 동봉한 `dataset-README.md`에 있다. [고정 데이터 카드](https://huggingface.co/datasets/Sophelio/fusion-equilibrium-challenge/blob/1e280905b85f2a6fdde7e06fca8cf3a1edf447cb/README.md) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)

공식 Hub 목록에는 저장소 파일 9,123개와 DIII-D 학습 파일 7,041개가 있었다. 기사용 익명 파일명 13개를 제외한 7,028개를 정렬하고 24개씩 세 묶음을 원파일 요청 전에 고정했다. 과거 번호가 공개된 별도 예제 182344, 182348, 203702, 203703, 203704의 파일 해시는 Hub 원파일과 달랐다. 이 다섯 자료를 포함한 과거 원파일 18개의 전체 3,903개 프레임과 이번 다섯 프레임을 검사했다. 채택 프레임의 원단위·정규화 배열 지문은 과거 프레임 및 서로와 일치하지 않았다. 실제 방전 번호와 캠페인 관계는 익명 자료만으로 확인할 수 없다.

| 사전 순위 | 익명 파일 ID | 1,400 ms 기하 검사 |
|---:|---|---|
| 1 | `13ced9c7c1` | 안쪽 분리면이 고정 벽 구간 70에 닿아 제외 |
| 2 | `332a6d97fc` | 통과, 안쪽 69 / 바깥쪽 68 |
| 3 | `e806f47778` | 통과, 안쪽 69 / 바깥쪽 68 |
| 4 | `b7684df369` | 분리면 계산이 EFIT 격자 밖을 요구해 제외 |
| 5 | `51d83022ca` | 통과, 안쪽 69 / 바깥쪽 68 |

고정한 원파일 다섯 개의 첫 HTTP 요청이 모두 성공했다. 순위 4의 자료에서 제외된 임시 입력을 정리할 때 Windows가 일시적으로 parquet 핸들을 점유했다. 같은 드라이버를 다시 실행해 앞선 체크포인트와 원파일을 재검증하고 그 순위부터 계속했다. 실행 기록은 `screen-retry-01.log`에 있다. 세 번째 통과 시 중단해 나머지 67개는 미검사로 남겼다.

## 파일 연결

- `protocol.ko.md`, `selection.json`, `downloads.json`, `preflight.json`이 시간비교 실험에서 사용하는 네 출처 기록이다. 네 파일의 SHA-256과 독립 재검산 결과는 `verification.json`에 있다.
- `hub-inventory.json`은 고정 Hub revision의 공식 응답 전체다. `ranked-paths.json`은 제외 후 모든 경로의 순서를 보존한다. `registration.json`은 첫 후보 요청 전의 selection SHA-256과 UTC를 고정한다.
- `prior-sources.json`은 과거 원파일·메타데이터의 경로와 해시를, `prior-frame-index.json`은 각 과거 파일의 시각·배열 차원·두 지문을 보존한다. 원단위와 정규화 배열에서 행·열 크기를 little-endian uint64 두 개로 먼저 부호화하고 C 순서 little-endian float64 바이트를 이어 SHA-256한다. 정규화에는 프레임 자체의 최솟값과 최댓값을 쓴다.
- `raw/`, `receipts/`, `requests/`에 원파일·크기·Hub LFS 해시·고정 URL·시각이 있다. `cases/<ID>/preflight.json`은 이전 체크포인트 해시를 포함한다. 통과한 `input-root`마다 원파일, 원래 벽 기하, 해당 시각의 벽·다리·공학 정책, 최소 manifest 네 파일만 있다. `source-code/manifest.json`에 검사 소스 파일 해시와 Python 라이브러리 버전이 있다.

## 보관 자료 재검산

프로젝트 D: 작업 트리에서 다음 PowerShell 명령을 실행한다. `verify`는 보관한 원파일과 등록 문서를 다시 읽어 전체 중복 비교, 순서·해시·시각 연결, 통과 입력 네 파일을 검산하고 실제 `nf_unused_live.load_cases` 결과를 출력한다.

```powershell
Set-Location -LiteralPath 'D:/DivertorOptimization/worktrees/d3d-report-correction-20261104'
$env:PYTHONPATH = 'D:/DivertorOptimization/worktrees/d3d-report-correction-20261104/.local_dependencies/d3d-fixed-equilibrium'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:TEMP = $env:TMP = 'D:/DivertorOptimization/tmp'
$env:HF_HOME = 'D:/DivertorOptimization/cache/huggingface'
$env:MPLCONFIGDIR = 'D:/DivertorOptimization/cache/matplotlib'
$env:OPENBLAS_NUM_THREADS = $env:MKL_NUM_THREADS = $env:OMP_NUM_THREADS = $env:NUMEXPR_NUM_THREADS = '1'
& 'C:/Users/FPL-user/miniforge3/python.exe' -m verification.nf_prospective_inputs --phase verify
```

기하를 처음부터 재현할 때에는 D:의 별도 빈 study 폴더에 같은 `protocol.ko.md`, `hub-inventory.json`, `prior-sources.json`, `dataset-README.md`를 복사한다. 이 과거 파일 목록은 2026-11-07 선택 시점의 경계를 고정한다. 같은 Python 모듈을 `--study <새 폴더> --phase register`, `--phase screen`, `--phase verify` 순서로 실행한다. 새 실행의 시각·절대 경로·상위 기록 해시는 새로 생성된다.
