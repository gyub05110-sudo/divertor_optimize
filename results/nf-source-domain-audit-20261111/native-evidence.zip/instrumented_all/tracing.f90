module audit_tracing
use iso_fortran_env
use flare_mmesh_unstructured_tracing
use flare_mmesh_unstructured_mmesh
implicit none
integer :: diagnostic_tmap_clamps=0
integer, parameter :: max_bsteps=1024
contains
  subroutine audit_bstep(this, c, ds, istat, n, u)
  !
  ! take a step along a field line
  !
  ! input:
  !    c           initial coordinates
  !    ds          step size (arc length)
  !    istat = 0:  initial location in volume
  !           -1:  initial location on lower side of boundary
  !           -2:  initial location on lower side of boundary
  !
  ! output:
  !    c           new coordinates
  !    ds          remaining step size (in case istat = -1)
  !    istat = 0:  step was successful
  !          1,2:  error in torosf_map
  !            3:  reached max. number of steps allowed
  !           -1:  step terminated on lower side of boundary
  !           -2:  step terminated on upper side of boundary
  !    n, u        direction flag for istat = 0 after mapping on up/down symmetric surface
  !                boundary coordinates for istat = -1 or -2
  !
  class(tracing_workspace), intent(in   ) :: this
  type(mcoords_workspace),  intent(inout) :: c
  real(real64),             intent(inout) :: ds
  integer,                  intent(inout) :: istat
  integer,                  intent(  out) :: n
  real(real64),             intent(  out) :: u(2)

  real(real64), parameter :: boundary_offset = 1.d-7

  real(real64) :: r1, r2, t1, t2, dt, p1(3), px(3), x
  integer :: ids, idt, idt0, idphi, iphi, iphi1, iphi_tube(0:1), iside, istep


  ! move position off boundary surface if necessary
  if (istat == -1 .or. istat == -2) then
     c%t = c%t + sign(boundary_offset, ds)
     c%p = this%mesh%rzphicoords(c%mcoords)
     istat = 0
  endif


  r1 = 1.d0
  ids = 1 ! directional flag for ds (can change at up/down symmetric surfaces)
  istat = 0
  do istep=1,max_bsteps
     iphi_tube = this%mesh%iphi_zone(:, this%mesh%izone_tube(c%itube))
     iphi1 = c%iphi
     t1 = iphi1 + c%t
     dt = r1 * ds * ids * this%bstep_params(c%itube)
     t2 = t1 + dt

     ! below lower boundary
     if (t2 < iphi_tube(0)) then
        c%iphi = iphi_tube(0)
        c%t = 0.d0
        idt = -1
        r2 = r1 * (t2 - iphi_tube(0)) / dt

     ! above upper boundary
     elseif (t2 > iphi_tube(1)) then
        c%iphi = iphi_tube(1) - 1
        c%t = 1.d0
        idt = 1
        r2 = r1 * (t2 - iphi_tube(1)) / dt

     ! inside flux tube
     else
        c%iphi = int(t2)
        c%t = t2 - c%iphi
        idt = 0
        r2 = 0.d0
     endif

     ! check for intersection with boundary
     if (this%boundary_flag(c%itube) == 1) then
        idphi = 1;   if (dt < 0.d0) idphi = -1
        iside = torosf_side(idphi)
        do iphi=iphi1,c%iphi,idphi
           p1 = c%p
           if (iphi == c%iphi) then
              c%p = this%mesh%rzphicoords(c%mcoords)
           else
              c%p = [this%mesh%rzcoords(c%itube, iphi+iside, c%xi), this%mesh%phi(iphi+iside)]
           endif
           if (this%boundary%intersect(p1, c%p, px, x, n, u)) then
              istat = istat_side(this, p1, c%p, px, n, u)

              c%iphi = iphi
              c%t = (px(3) - this%mesh%phi(iphi)) / (this%mesh%phi(iphi+1) - this%mesh%phi(iphi))
              c%p = px
              r2 = r1 * (1.d0 - (c%iphi + c%t - t1) / dt)
              ds = ids * r2 * ds
              return
           endif
        enddo
     endif
     r1 = r2

     ! finished tracing?
     n = ids
     if (idt == 0) return

     ! move on to next flux tube
     idt0 = idt
     call this%mesh%torosf_map(c%mcoords, idt, istat)
     if (istat < 0) then
         diagnostic_tmap_clamps=diagnostic_tmap_clamps+1
         ! continue at radial/poloidal domain boundary, BETTER: check if deviation is small
         c%xi(2) = -0.9999876543210d0
         istat = 0
     endif
     if (istat /= 0) return
     ids = ids * idt * idt0 ! update ids after torosf_map

     ! NOTE: this should only be necessary if the previous cell had boundary_flag = 0
     ! or after mapping at the upper and lower toroidal boundary of the simulation domain
     if (this%boundary_flag(c%itube) == 1) c%p = this%mesh%rzphicoords(c%mcoords)
  enddo
  istat = 3

  end subroutine audit_bstep
  !-----------------------------------------------------------------------------


  !-----------------------------------------------------------------------------
  function istat_side(this, p1, p2, px, n, u)
  class(tracing_workspace), intent(in   ) :: this
  real(real64), intent(in) :: p1(3), p2(3), px(3), u(2)
  integer,      intent(in) :: n
  integer                  :: istat_side

  real(real64) :: v(3)


  istat_side = -1
  v = p2 - p1
  v(3) = v(3) * px(1)
  if (sum(v * this%boundary%normal_vector(n, u)) < 0.d0) istat_side = -2

  end function istat_side
end module audit_tracing
