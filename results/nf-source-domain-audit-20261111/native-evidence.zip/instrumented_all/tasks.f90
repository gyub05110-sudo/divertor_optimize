module firefly_tasks
  use iso_fortran_env
  use moose_geometry, only: target_mesh3d
  use moose_data,     only: dataset
  implicit none


  ! results from strike point density and heat load proxy
  type(dataset) :: results

  real(real64), allocatable :: summary(:,:), wside(:,:)
  real(real64) :: loss(2), total_src
  logical :: results_initialized = .false.


  ! results from particle exhaust proxy: ionization in core and edge/SOL
  real(real64) :: sp(2), emin_fast, lost_particles
  type(dataset) :: n0_results

  contains
  !-----------------------------------------------------------------------------


  !-----------------------------------------------------------------------------
  subroutine init_results(kind)
  use moose_data,       only: CELL_DATA
  use firefly_geometry, only: pfc_mesh, nsurfaces
  use firefly_version
  character(len=*), intent(in), optional :: kind


  if (results_initialized) then
     call results%free()
     deallocate (summary, wside)
  endif


  allocate (summary(2, nsurfaces), source = 0.d0)
  allocate (wside(2, nsurfaces), source = 0.d0)
  results = dataset(2, pfc_mesh, CELL_DATA, kind=kind)
  results_initialized = .true.
  call results%annotations%set("firefly_version", version)

  end subroutine init_results
  !-----------------------------------------------------------------------------


  !-----------------------------------------------------------------------------
  subroutine post_proc_results(computation_time)
  use moose_mpi
  use firefly_geometry, only: pfc_mesh, pfc_props
  real(real64), intent(in) :: computation_time

  real(real64) :: wmax, wsum
  integer :: i, k1, k2, auto_plasma_side


  associate (M => pfc_mesh, D => results)

  ! 1. collect integral fluxes
  do i=1,size(M%refined_tpzmesh3d)
     k1 = M%block_structured%cell_offset(i)
     k2 = M%block_structured%cell_offset(i+1) - 1
     summary(1, i) = sum(D%values(1,k1:k2)) / total_src * 100.d0
  enddo

  ! 2. evaluate strike point density / heat loads
  D%values(2,:) = M%cell_area()
  where (D%values(2,:) > 0.d0) D%values(1,:) = D%values(1,:) / D%values(2,:)
  do i=1,size(M%refined_tpzmesh3d)
     k1 = M%block_structured%cell_offset(i)
     k2 = M%block_structured%cell_offset(i+1) - 1
     summary(2, i) = maxval(D%values(1,k1:k2))
  enddo

  ! 3. print summary
  if (rank == 0) then
     print *
     print *, "results:                              contrib.         max. [m**(-2)]   surface side"
     do i=1,size(M%refined_tpzmesh3d)
        auto_plasma_side = 1;   if (wside(2,i) > wside(1,i)) auto_plasma_side = -1
        wmax = maxval(wside(:,i))
        wsum = sum(wside(:,i))
        if (wsum > 0.d0) then
           print 4001, i-1, M%refined_tpzmesh3d(i)%title(), summary(:, i), auto_plasma_side, wmax / wsum * 100
           pfc_props(i)%plasma_side = auto_plasma_side
        else
           print 4002, i-1, M%refined_tpzmesh3d(i)%title(), summary(:, i)
           pfc_props(i)%plasma_side = 0
        endif
        call M%refined_tpzmesh3d(i)%annotations%set("plasma_side", pfc_props(i)%plasma_side)
     enddo
     print *
     if (any(loss > 0.d0)) print *, "loss = ", loss
     print *, "computation time: ", computation_time, " s"
     print *
     print *
  endif
  do i=1,size(M%refined_tpzmesh3d)
     call proc(0)%broadcast(pfc_props(i)%plasma_side)
  enddo
 4001 format(i4,1x,a32,2x,f8.3," %",8x,e12.5,6x,i2,1x,"(",f6.2," %)")
 4002 format(i4,1x,a32,2x,f8.3," %",8x,e12.5)

  end associate
  end subroutine post_proc_results
  !-----------------------------------------------------------------------------


  !-----------------------------------------------------------------------------
  subroutine connection_length(filename, max_lc, output)
  !
  ! Compute field line connection length for set of initial points. This is the
  ! equivalent of the :ref:`fieldline_connection` task but using field line
  ! reconstruction instead of numerical integration.
  !
  ! **Parameters:**
  !
  ! :filename:  Name of :class:`moose:moose.grids.R3grid` file for initial points.
  !
  ! :max_lc:    Truncation for field line length [m].
  !
  use moose_mpi
  use moose_grids, only: r3grid
  use moose_dataset
  use flare_control, only: report, progress_bar, finalize_progress_bar
  use firefly_geometry
  character(len=*), intent(in) :: filename, output
  real(real64),     intent(in) :: max_lc

  type(r3grid)  :: grid
  type(dataset) :: D
  type(mcoords) :: c, c0
  real(real64), pointer :: element(:)
  real(real64) :: dl, lc(-1:1), t, t1, t2, tx, p1(3), p2(3), x(3), x0(3), u(2)
  real(real64) :: strikes(2,-1:1)
  integer :: i, idt, idt0, ierr, iphi, iphi1, iphi_tube(0:1), n, nnodes


  call assert_mmesh_and_pfc("connection_length")


  if (report) then
     print *, "Loading grid for sampling of connection length ..."
     grid = r3grid(filename)
     print *, "... done"
     print *

     print *, "Computing connection length ..."
     print *
  endif
  call grid%broadcast()


  call cpu_time(t1)
  nnodes = grid%nnodes()
  D = dataset(7, nnodes)
  call D%set_geometry(filename, output)
  call D%set_metadata(1, 'Lc_neg')
  call D%set_metadata(2, 'Lc_pos')
  call D%set_metadata(3, 'ierr')
  call D%set_metadata(4, 'R_neg')
  call D%set_metadata(5, 'Z_neg')
  call D%set_metadata(6, 'R_pos')
  call D%set_metadata(7, 'Z_pos')
  call D%set_expression("Lc", "Lc_neg + Lc_pos", label="Connection length", units="m")
  call progress_bar(0, nnodes)
  do i=rank,nnodes-1,nproc
     x0 = grid%node(i)
     call mesh%mcoords(x0, c0, 0, ierr)
     if (ierr /= 0) then
        !print *, x0, i, ierr
        D%values(3,i) = 1
        cycle
     endif

     strikes = 0.d0
     do idt0=-1,1,2
        idt = idt0
        c = c0
        p1(1:2) = mesh%rzcoords(c)
        p1(3) = mesh%phi(c%iphi) + c%t * (mesh%phi(c%iphi+1) - mesh%phi(c%iphi))
        lc(idt) = tracing%arclength(c%itube, c%iphi)
        if (idt == 1) then
           iphi1 = c%iphi + 1
           t = 1.d0 - c%t
        else
           iphi1 = c%iphi
           t = c%t
        endif
        lc(idt) = lc(idt) * t

        p2(1:2) = mesh%rzcoords(c%itube, iphi1, c%xi)
        p2(3) = mesh%phi(iphi1)
        if (tracing%boundary_flag(c%itube) == 1 .and. pfc%intersect(p1, p2, x, tx, n, u)) then
           strikes(:,idt0) = x(1:2)
           lc(idt) = lc(idt) * tx
           cycle
        endif


        trace_loop: do
           iphi_tube = mesh%iphi_zone(:, mesh%izone_tube(c%itube))
           p1(1:2) = mesh%rzcoords(c%itube, iphi1, c%xi)
           p1(3) = mesh%phi(iphi1)
           do iphi=iphi1,iphi_tube(torosf_side(idt))-idt,idt
              dl = tracing%arclength(c%itube, c%iphi)
              if (tracing%boundary_flag(c%itube) == 1) then
              p2(1:2) = mesh%rzcoords(c%itube, iphi+idt, c%xi)
              p2(3) = mesh%phi(iphi+idt)

              if (pfc%intersect(p1, p2, x, tx, n, u)) then
                 strikes(:,idt0) = x(1:2)
                 lc(idt0) = lc(idt0) + tx * dl
                 exit trace_loop
              endif
              p1 = p2
              endif
              lc(idt0) = lc(idt0) + dl
           enddo
           if (lc(idt0) > max_lc) exit trace_loop

           call mesh%torosf_map(c, idt, ierr)
           if (ierr /= 0) then
              !print *, i, c, ierr
              D%values(3,i) = 2
              exit trace_loop
           endif
           iphi1 = mesh%iphi_zone(torosf_side(-idt), mesh%izone_tube(c%itube))
        enddo trace_loop
     enddo

     element => D%element(i)
     element(1) = lc(-1)
     element(2) = lc(1)
     element(4:7) = [strikes(:,-1),strikes(:,1)]
     call progress_bar(i+1, nnodes)
  enddo
  call finalize_progress_bar()
  call D%allreduce()
  call cpu_time(t2)
  if (rank == 0) print *, "... finished, total time: ", t2 - t1, " s"

  if (rank == 0) call D%savetxt(output)
  call D%free()

  end subroutine connection_length
  !-----------------------------------------------------------------------------


  !-----------------------------------------------------------------------------
  subroutine strike_point_density(dcoeff, nsamples, bstep, output)
  !
  ! Compute the strike point density of magnetic field lines on divertor targets,
  ! baffles and the first wall. This is the equivalent of the :ref:`fieldline_connection`
  ! task with artifical cross-field diffusion and processing the output with the
  ! :ref:`strike_point_density` task. Field lines are initialized along the
  ! inner mesh boundary here. The output is a :class:`moose:moose.data.Dataset`
  ! that can be visualized with the :ref:`moose:mplot` and/or :ref:`moose:mplot3d` commands.
  !
  !
  ! **Parameters:**
  !
  ! :dcoeff:     Field line diffusion coefficient [m**2 / m].
  !
  ! :nsamples:   Number of field line samples.
  !
  ! :bstep:      Step size along field lines [m].
  !
  use moose_mpi
  use moose_math
  use moose_geometry, only: target_mesh3d
  use moose_dataset
  use flare_control
  use flare_mmesh_unstructured_sampling
  use flare_mmesh_unstructured_tracing
  use firefly_geometry
  real(real64),     intent(in) :: dcoeff, bstep
  integer,          intent(in) :: nsamples
  character(len=*), intent(in) :: output

  type(mcoords_workspace) :: c
  type(source) :: S
  real(real64) :: w, xstep, dx(2), ds, u(2), r, t1, t2
  integer :: i, icell, ids, istat, n


  call assert_mmesh_and_pfc("strike_point_density")


  total_src = 1.d0 / abs(mesh%symmetry);   if (mesh%symmetry < 0) total_src = total_src / 2
  if (report) then
     print *, "Computing strike point density ..."
     print *
     print *, "dcoeff = ", dcoeff
     print *, "nsamples = ", nsamples
     print *, "total source = ", total_src
     print *
  endif


  ! initialize pfc mesh with fine resolution
  call init_results("strike_point_density")
  associate (M => pfc_mesh, D => results)
  call cpu_time(t1)
  call D%set_metadata(1, "p", "Strike point density", "m**(-2)")
  call D%set_metadata(2, "area", "Surface area per cell", "m**2")
  call D%set_parameter("dcoeff", dcoeff)
  call D%set_parameter("bstep", bstep)
  call D%set_parameter("nsamples", nsamples)


  ! jump steps [m]
  xstep = sqrt(2 * bstep * dcoeff)
  if (report) then
     print *, "xstep, bstep = ", xstep, bstep
     print *
  endif


  loss = 0.d0
  S = surface_source(mesh, ISB_TAG, 1, total_src, nsamples)
  call progress_bar(0, nsamples)
  do i=1+rank,nsamples,nproc
     ! sample new particle
     call S%sample(c%mcoords, w)
     if (tracing%boundary_flag(c%itube) == 1) c%p = mesh%rzphicoords(c%mcoords)
     call random_number(r)
     ids = 2 * int(2*r) - 1

     ! trace particle until it reaches divertor targets
     trace_loop: do
        ! 1. cross-field step
        dx = random_number_stdnorm2d() * xstep
        call tracing%xstep(c, dx, istat, n, u)
        ! - at targets
        if (istat == -1 .or. istat == -2) then
           icell = M%bin_index(n, u)
           D%values(1,icell) = D%values(1,icell) + w
           wside(-istat,n) = wside(-istat,n) + w
           exit trace_loop

        ! - reflection at inner boundary
        elseif (mod(istat, 10) == ISB_TAG) then
           c%xi(2) = -0.9999876543210d0
           istat = 0

        ! - out of bounds
        elseif (istat /= 0) then
           !print *, "cross-field step exited with istat = ", istat
           loss(1) = loss(1) + w
           exit trace_loop
        endif


        ! 2. step along field line
        ds = ids * bstep
        bstep_loop: do
           call tracing%bstep(c, ds, istat, n, u)
           ! - finished bstep
           if (istat == 0) then
               ids = ids * n
               exit bstep_loop

           ! - at targets
           elseif (istat == -1 .or. istat == -2) then
              icell = M%bin_index(n, u)
              D%values(1,icell) = D%values(1,icell) + w
              wside(-istat,n) = wside(-istat,n) + w
              exit trace_loop

           ! - out of bounds
           else
              loss(2) = loss(2) + w
              exit trace_loop
           endif
        enddo bstep_loop
     enddo trace_loop
     call progress_bar(i, nsamples)
  enddo
  call finalize_progress_bar()
  call D%allreduce()
  call moose_mpi_sum(loss)
  call moose_mpi_sum(wside)
  call cpu_time(t2)


  ! prepare summary and save results
  call post_proc_results(t2 - t1)
  if (rank == 0) call D%savenc(output)

  end associate
  end subroutine strike_point_density
  !-----------------------------------------------------------------------------


  !-----------------------------------------------------------------------------
  subroutine heat_load_proxy(n0, T0, chi, nparticles, pload, tau, output)
  !
  ! Compute heat loads onto divertor targets, baffles and the first wall based
  ! on fixed background plasma (linearized heat conduction). Heat loads are
  ! normalized to the total power exhaust.
  ! The output is a :class:`moose:moose.data.Dataset` that can be visualized
  ! with the :ref:`moose:mplot` and/or :ref:`moose:mplot3d` commands.
  !
  !
  ! **Parameters:**
  !
  ! :n0:         Background plasma density [m**(-3)].
  !
  ! :T0:         Background plasma temperature [eV].
  !
  ! :chi:        Cross-field heat diffusion coefficient [m**2 / m].
  !
  ! :nparticles: Number of test particles.
  !
  ! :pload:      Probability for PFC loading (default: sheath heat transmission condition)
  !
  ! :tau:        Time step for particle tracing [s].
  !
  use audit_tracing, only: audit_bstep, diagnostic_tmap_clamps
  use flare_model, only: equi2d
  use moose_mpi
  use moose_math
  use moose_geometry, only: target_mesh3d
  use moose_dataset
  use flare_control
  use flare_mmesh_unstructured_sampling
  use flare_mmesh_unstructured_tracing
  use firefly_geometry
  real(real64),     intent(in) :: n0, T0, chi
  integer,          intent(in) :: nparticles
  real(real64),     intent(in) :: pload, tau
  character(len=*), intent(in) :: output

  real(real64), parameter :: &
     echarg        = 1.602176634d-19, &
     mp            = 1.67262192369d-27, &
     cs_prefac     = sqrt(echarg / mp), &
     kappa_prefac  = 2060 / echarg, &
     sheath_factor = 7.d0

  type(mcoords_workspace) :: c
  type(source) :: S
  real(real64) :: cs, kappa, lt_para, a, pload_
  real(real64) :: w, wload, xstep, bstep, dx(2), ds, u(2), t1, t2
  integer :: i, icell, istat, n, ndonor, iu, src_i, lo, hi, mid
  integer :: cap_index, kcap, nstep, nreflect, nlimit
  real(real64) :: untraced, max_seconds
  character(len=32) :: time_setting
  type(mcoords_workspace) :: before_x
  character(len=512) :: src_path
  real(real64), allocatable :: rsrc(:), zsrc(:), cdf(:)
  integer :: disbstep, dtmapstep
  real(real64) :: dpreboth
  integer :: du, de, dhit, disb, dcapx, dcapb, dfirst, dfirststep, dfirstkind, dimpstep
  integer :: dcross, dcore, dpfr, dj, dk, dit, dkind, dcorestep, dpfrstep
  real(real64) :: dpower(2), dpreisb, dfirstload, dq(2), dqprev(2), dmaxz, dminz, dminr
  real(real64) :: dpsi, dpsimin, dpc(4), dxi(2), dcrossz, dcorerz(2), dpfrrz(2)
  real(real64), allocatable :: dflux(:,:)
  character(len=80) :: dfile
  real(real64) :: psrc(3), rand_src, rand_phi, check_rz(2)


  call assert_mmesh_and_pfc("head_load_proxy")


  total_src = 1.d0 / abs(mesh%symmetry);   if (mesh%symmetry < 0) total_src = total_src / 2
  if (report) then
     print *, "Computing heat load proxy ..."
     print *
     print *, "n0 = ", n0
     print *, "T0 = ", T0
     print *, "chi = ", chi
     print *, "nparticles = ", nparticles
     print *, "total source = ", total_src
     print *
  endif


  ! initialize pfc mesh with fine resolution
  call init_results("heat_load_proxy")
  associate (M => pfc_mesh, D => results)
  call cpu_time(t1)
  call D%set_parameter("n0", n0)
  call D%set_parameter("T0", T0)
  call D%set_parameter("chi", chi)
  call D%set_parameter("nparticles", nparticles)
  call D%set_parameter("tau", tau)
  call D%set_metadata(1, "hload", "Heat load / power", "m**(-2)")
  call D%set_metadata(2, "area", "Surface area per cell", "m**2")


  ! pre-compute transport coefficients
  ! sound speed of hydrogen [m/s] with Te = Ti
  call get_environment_variable("FIREFLY_MIDPLANE_SOURCE",src_path)
  cs = cs_prefac * sqrt(2 * T0)
  ! parallel heat conductivity (normalized to n0) [m**2 / s]
  kappa = kappa_prefac * T0**2.5d0 / n0
  if (len_trim(src_path)>0) then
     ! DIII-D study uses deuterium and kappa_0=2000 in SI with T[eV].
     cs = sqrt(2.d0 * echarg * T0 / 3.3435837724d-27)
     kappa = 2000.d0 / echarg * T0**2.5d0 / n0
     open(newunit=iu,file=trim(src_path),status="old",action="read")
     read(iu,*) ndonor
     allocate(rsrc(ndonor),zsrc(ndonor),cdf(ndonor))
     do src_i=1,ndonor
        read(iu,*) rsrc(src_i), zsrc(src_i), cdf(src_i)
     enddo
     close(iu)
     if (cdf(1)<=0.d0 .or. any(cdf(2:)<cdf(:ndonor-1)) .or. abs(cdf(ndonor)-1.d0)>1.d-12) error stop "invalid source CDF"
     cdf(ndonor)=1.d0
  endif
  cap_index=0
  do kcap=1,pfc%nsurfaces
     if (trim(pfc%surfaces(kcap)%key)=="reflect_midplane") cap_index=kcap
  enddo
  if (cap_index>0 .and. len_trim(src_path)==0) error stop "reflection requires midplane source"
  if (rank==0) print *, "midplane reflector index:",cap_index
  ! parallel T-decay length [m]
  lt_para = kappa / sheath_factor / cs
  ! jump steps [m]
  xstep = sqrt(2 * tau * chi)
  bstep = sqrt(2 * tau * kappa)
  ! loss probability (target loading)
  a = sqrt(pi/2) * bstep / lt_para
  if (pload >= 0.d0) then
     pload_ = pload
  else
     pload_ = a / (1.d0 + 0.5d0 * a)
  endif
  if (report) then
     print *, "xstep, bstep, pload = ", xstep, bstep, pload_
     print *
  endif


  loss = 0.d0
  S = surface_source(mesh, ISB_TAG, 1, total_src, nparticles)
  untraced=0.d0
  max_seconds=0.002d0
  call get_environment_variable("FIREFLY_HISTORY_SECONDS",time_setting)
  if (len_trim(time_setting)>0) read(time_setting,*) max_seconds
  if (max_seconds<=0.d0) error stop "invalid history cutoff"
  nlimit=ceiling(max_seconds/tau)
  write(dfile,'("history-rank",i1,".txt")') rank
  open(newunit=du,file=trim(dfile),status="replace")
  write(du,'(a)') "# i steps first_region first_step first_kind wall_hits ISB cap_x cap_b core pfr cross core_step pfr_step imp_step " // &
    "imp_weight other_weight imp_before_ISB first_load max_Z min_Z min_R min_psi_interp crossing_Z core_R core_Z pfr_R pfr_Z tmap_clamps first_ISB_step first_tmap_step imp_before_both"
  allocate(dflux(4,0:mesh%ntubes-1))
  do dit=0,mesh%ntubes-1
     do dj=1,4
        dq=mesh%rzcoords(mesh%corner(dj,dit),mesh%lbound_tube(dit))
        dflux(dj,dit)=equi2d%psiN(dq)
     enddo
  enddo
  call progress_bar(0, nparticles)
  do i=1+rank,nparticles,nproc
     ! sample new particle
     if (len_trim(src_path)==0) then
        call S%sample(c%mcoords,w)
     else
        ! Stratify the inverse-CDF source across all MPI ranks, one equal-weight history per stratum.
        call random_number(rand_src)
        rand_src = (i-1+rand_src)/nparticles
        lo=1; hi=ndonor
        do while (lo<hi)
           mid=(lo+hi)/2
           if (cdf(mid)>=rand_src) then
              hi=mid
           else
              lo=mid+1
           endif
        enddo
        call random_number(rand_phi)
        psrc=[rsrc(lo),zsrc(lo),mesh%phi(0)+rand_phi*(mesh%phi(mesh%nphi-1)-mesh%phi(0))]
        ! A 0.1 micron inward offset resolves a launch directly on the reflecting face.
        if (cap_index>0) psrc(2)=psrc(2)-1.d-7
        call mesh%mcoords(psrc,c%mcoords,0,istat)
        if (istat/=0) error stop "midplane source outside mesh"
        check_rz=mesh%rzcoords(c%mcoords)
        if (norm2(check_rz-psrc(1:2))>1.d-7) error stop "midplane source round trip"
        w=S%w0
     endif
     if (tracing%boundary_flag(c%itube) == 1) c%p = mesh%rzphicoords(c%mcoords)

     ! trace particle until it reaches divertor targets
     disbstep=0;dtmapstep=0;dpreboth=0.d0
     diagnostic_tmap_clamps=0
     dhit=0;disb=0;dcapx=0;dcapb=0;dfirst=0;dfirststep=0;dfirstkind=0;dimpstep=0
     dcross=0;dcore=0;dpfr=0;dcorestep=0;dpfrstep=0
     dpower=0.d0;dpreisb=0.d0;dfirstload=0.d0;dcrossz=99.d0;dcorerz=99.d0;dpfrrz=99.d0
     dqprev=psrc(1:2);dmaxz=psrc(2);dminz=psrc(2);dminr=psrc(1);dpsimin=99.d0
     nstep=0
     trace_loop: do
        nstep=nstep+1
        if (len_trim(src_path)>0 .and. nstep>nlimit) then
           untraced=untraced+w
           exit trace_loop
        endif
        ! 1. cross-field step
        dx = random_number_stdnorm2d() * xstep
        if (cap_index>0) before_x=c
        call tracing%xstep(c, dx, istat, n, u)
        ! - at targets
        if (istat == -1 .or. istat == -2) then
           if (n==cap_index) then
              ! Reject the transversal increment across the zero-flux cut.
              dcapx=dcapx+1
              c=before_x
              istat=0
           else
           icell = M%bin_index(n, u)
           call diagnostic_wall(w,1)
           D%values(1,icell) = D%values(1,icell) + w
           wside(-istat,n) = wside(-istat,n) + w
           exit trace_loop
           endif

        ! - reflection at inner boundary
        elseif (mod(istat, 10) == ISB_TAG) then
           if(disbstep==0) disbstep=nstep
           disb=disb+1
           c%xi(2) = -0.9999876543210d0
           ! Keep the tracked physical point on the same magnetic coordinate after the inner-boundary clamp.
           ! A stale Cartesian point can put a nominal midplane impact on the opposite side of the cut.
           if (cap_index>0 .and. tracing%boundary_flag(c%itube)==1) c%p=mesh%rzphicoords(c%mcoords)
!           dx = -dx
!           call tracing%xstep(c, dx, istat, n, u)
!           if (istat /= 0) then
!              loss(3) = loss(3) + w
!              exit trace_loop
!           endif
           istat = 0

        ! - out of bounds
        elseif (istat /= 0) then
           !print *, "cross-field step exited with istat = ", istat
           loss(1) = loss(1) + w
           exit trace_loop
        endif


        call diagnostic_position()

        ! 2. step along field line
        ds = random_number_stdnorm() * bstep
        nreflect=0
        bstep_loop: do
           nreflect=nreflect+1
           if (len_trim(src_path)>0 .and. nreflect>1000) then
              untraced=untraced+w
              exit trace_loop
           endif
           call audit_bstep(tracing,c,ds,istat,n,u)
           if(dtmapstep==0.and.diagnostic_tmap_clamps>0) dtmapstep=nstep
           call diagnostic_position()
           ! - finished bstep
           if (istat == 0) then
               exit bstep_loop

           ! - at targets
           elseif (istat == -1 .or. istat == -2) then
              if (n==cap_index) then
                 ! Continue the residual parallel displacement in the lower leg.
                 dcapb=dcapb+1
                 ds=-ds
                 cycle bstep_loop
              endif
              call S%boundary_event(w, pload_, wload)
              ! Diagnostic records zero-load encounters as real first impacts too.
              call diagnostic_wall(wload,2)
              if (wload > 0.d0) then
                 icell = M%bin_index(n, u)
                 D%values(1,icell) = D%values(1,icell) + wload
                 wside(-istat,n) = wside(-istat,n) + wload
              endif
              if (w == 0.d0) exit trace_loop
              ds = -ds

           ! - out of bounds
           else
              loss(2) = loss(2) + w
              exit trace_loop
           endif
        enddo bstep_loop
     enddo trace_loop
     write(du,*) i,nstep,dfirst,dfirststep,dfirstkind,dhit,disb,dcapx,dcapb,dcore,dpfr,dcross, &
       dcorestep,dpfrstep,dimpstep,dpower,dpreisb,dfirstload,dmaxz,dminz,dminr,dpsimin,dcrossz,dcorerz,dpfrrz,diagnostic_tmap_clamps,disbstep,dtmapstep,dpreboth
     flush(du)
     call progress_bar(i, nparticles)
  enddo
  close(du)
  deallocate(dflux)
  call finalize_progress_bar()
  call D%allreduce()
  call moose_mpi_sum(loss)
  call moose_mpi_sum(untraced)
  if (rank==0) then
     print *, "censored full-torus fraction",untraced/total_src
     call D%set_parameter("max_history_seconds",max_seconds)
     call D%set_parameter("censored_fraction",untraced/total_src)
     call D%set_parameter("domain_loss_fraction",sum(loss)/total_src)
  endif
  call moose_mpi_sum(wside)
  call cpu_time(t2)


  ! prepare summary and save results
  call post_proc_results(t2 - t1)
  if (rank == 0) call D%savenc(output)

  end associate
  contains
  subroutine diagnostic_wall(dw,kind)
  real(real64), intent(in) :: dw
  integer, intent(in) :: kind
  integer :: region
  ! Physical original segments 69 and lower segment 70; exact receiver mask used in analysis.
  region=2
  if(c%p(1)<=1.1645d0+1.d-7.and.c%p(2)<=-1.15d0+1.d-7) region=1
  dhit=dhit+1
  if(dhit==1) then
     dfirst=region;dfirststep=nstep;dfirstkind=kind;dfirstload=dw
  endif
  if(region==1.and.dimpstep==0) dimpstep=nstep
  dpower(region)=dpower(region)+dw
  if(region==1.and.disb==0) dpreisb=dpreisb+dw
  if(region==1.and.disb==0.and.diagnostic_tmap_clamps==0) dpreboth=dpreboth+dw
  end subroutine
  subroutine diagnostic_position()
  real(real64) :: q(2), v, a,b,zz
  if(tracing%boundary_flag(c%itube)==1) then
    q=c%p(1:2)
  else
    q=mesh%rzcoords(c%mcoords)
  endif
  dmaxz=max(dmaxz,q(2));dminz=min(dminz,q(2));dminr=min(dminr,q(1))
  if(dcross==0.and.dqprev(1)>1.3907611897953485d0.and.q(1)<=1.3907611897953485d0) then
    dcross=nstep
    dcrossz=q(2)
  endif
  dqprev=q
  a=(c%xi(1)+1.d0)/2.d0;b=(c%xi(2)+1.d0)/2.d0
  ! Quad corner order verified against moose kvert: (-1,-1),(1,-1),(1,1),(-1,1).
  v=(1-a)*(1-b)*dflux(1,c%itube)+a*(1-b)*dflux(2,c%itube) &
    +a*b*dflux(3,c%itube)+(1-a)*b*dflux(4,c%itube)
  dpsimin=min(dpsimin,v)
  if(v<1.d0) then
    if(dcore==0.and.q(2)>-1.070269770906762d0) then
      if(equi2d%psiN(q)<1.d0) then
        dcore=1;dcorestep=nstep;dcorerz=q
      endif
    endif
    if(dpfr==0.and.q(2)<-1.070269770906762d0) then
      if(equi2d%psiN(q)<1.d0) then
        dpfr=1;dpfrstep=nstep;dpfrrz=q
      endif
    endif
  endif
  end subroutine
  end subroutine heat_load_proxy
  !-----------------------------------------------------------------------------


  !-----------------------------------------------------------------------------
  subroutine set_recycling(filename)
  !
  ! Set recycling proxy from a previous strike_point_density or heat_load_proxy calculation.
  !
  use moose_error
  use moose_mpi
  use moose_netcdf
  use moose_utils,    only: str
  use moose_dataset
  use moose_geometry, only: target_mesh3d
  use firefly_geometry
  character(len=*), intent(in) :: filename

  type(netcdf_dataset) :: nc, nc_grid, nc_domain, nc_block
  character(len=128)   :: key, kind, varname
  real(real64), allocatable :: dphi(:), ds(:)
  integer, allocatable :: ncids(:), varids(:)
  integer :: checksum, i, istat, k1, k2, nblocks, numgrps, nvars, ncells


  ! mmesh and pfc must already be defined
  call assert_mmesh_and_pfc("set_recycling")
  call pfc_mesh%free()


  ! read layout & refinement parameters
  if (rank == 0) then
     nc = netcdf_open(filename)
     ! verify that dataset is strike point density or heat load proxy
     call nc%get_att("kind", kind)
     if (kind /= "strike_point_density"  .and.  kind /= "heat_load_proxy") then
        call ERROR("dataset of kind '" // trim(kind) // "' is not compatible with particle exhaust proxy")
     endif


     nc_grid = nc%group("grid")
     nc_domain = nc_grid%group("domain")
     call nc_domain%get_att("nblocks", nblocks)
     if (nblocks /= nsurfaces) call ERROR("number of surfaces in data file does not match pfc")


     ! read refinement parameters for pfc
     allocate (ncids(nblocks), dphi(nblocks), ds(nblocks))
     call nc_domain%inq_grps(numgrps, ncids)
     do i=1,nblocks
        nc_block = netcdf_dataset(ncids(i))
        call nc_block%inq_grpname(key)
        call nc_block%get_att("dphi", dphi(i))
        call nc_block%get_att("ds", ds(i))
        call nc_block%get_att("checksum", checksum)
        call nc_block%get_att("plasma_side", pfc_props(i)%plasma_side)
        ! verify that grid is consistent with pfc
        if (checksum /= pfc%surfaces(i)%geometry%checksum()) then
           call ERROR("checksum does not match for surface " // pfc%surfaces(i)%key)
        endif
     enddo
  endif
  call proc(0)%broadcast_allocatable(dphi)
  call proc(0)%broadcast_allocatable(ds)
  call proc(0)%broadcast(nblocks)
  do i=1,nblocks
     call proc(0)%broadcast(pfc_props(i)%plasma_side)
  enddo


  ! initialize pfc mesh with fine resolution
  pfc_mesh = target_mesh3d(pfc, dphi(1), ds(1))   ! NOTE: the same dphi, ds is used for all surfaces
  call init_results()
  associate (M => pfc_mesh, D => results)
  ! check if material_index needs to be redefined (in case resolution of tally mesh has changed)
  if (rank == 0) then
     do i=1,nsurfaces
        if (pfc_props(i)%material_index_def /= 3) cycle
        if (all(shape(pfc_props(i)%material_index) == pfc_mesh%refined_tpzmesh3d(i)%n-1)) cycle
        print 2001, trim(pfc%surfaces(i)%key)
     enddo
  endif
 2001 format("WARNING: material index must be redefined for '",a,"' due to resolution change")


  ! read data
  if (rank == 0) then
     ncells = nc%dim("cells")
     if (ncells /= M%block_structured%ncells()) call ERROR("unexpected number of cells in dataset")

     call nc%inquire(nVariables=nvars)
     allocate (varids(nvars))
     call nc%inq_varids(nvars, varids)
     do i=1,nvars
        call nc%inquire_variable(varids(i), varname)
        call nc%get_var(varname, D%values(i,:))
     enddo
     call nc%close()

     ! sanity check: verfify that plasma_side is set if needed
     do i=1,size(M%refined_tpzmesh3d)
        k1 = M%block_structured%cell_offset(i)
        k2 = M%block_structured%cell_offset(i+1) - 1
        if (any(D%values(1,k1:k2) > 0.d0) .and. pfc_props(i)%plasma_side == 0) then
           call ERROR("undefined plasma_side, pfc_index = " // str(i))
        endif
     enddo
  endif
  call proc(0)%broadcast(D%values)
  end associate

  end subroutine set_recycling
  !-----------------------------------------------------------------------------


  !-----------------------------------------------------------------------------
  subroutine particle_exhaust_proxy(ncore, Tcore, nedge, Tedge, nparticles, output, sp_core, pumped, lost)
  !
  ! Compute particle exhaust and core ionization proxy.
  !
  !
  ! **Parameters:**
  !
  ! :ncore:        Density in plasma core [m**(-3)].
  !
  ! :Tcore:        Temperature in plasma core [eV].
  !
  ! :nedge:        Density in plasma edge / scrape-off layer [m**(-3)].
  !
  ! :Tedge:        Temperature in plasma edge / scrape-off layer [eV].
  !
  ! :nparticles:   Number of test particles.
  !
  !
  ! **Results:**
  !
  ! :sp_core:      Ionization in plasma core.
  !
  ! :pumped:       Particle exhaust through pumping surface.
  !
  ! :lost:         Lost particles.
  !
  use moose_error
  use moose_mpi
  use moose_data,       only: CELL_DATA
  use flare_control
  use firefly_version
  use firefly_geometry, only: nsurfaces, pfc_mesh
  use firefly_plasma
  use firefly_sampling
  real(real64),     intent(in   ) :: ncore, nedge, Tcore, Tedge
  integer,          intent(in   ) :: nparticles
  character(len=*), intent(in   ) :: output
  real(real64),     intent(  out) :: sp_core, pumped, lost

  real(real64) :: t1, t2
  integer, save :: icall_eirene = 1
  integer :: isurf


  if (report) then
     print *, "Computing particle exhaust proxy ..."
     print *
     print *, "             density [m**(-3)]    temperature [eV]"
     print 1001, ncore, Tcore
     print 1002, nedge, Tedge
     print *, "nparticles = ", nparticles
     print *
     print *, "Tracing neutral particles ..."
  endif
 1001 format(1x,"core:       ", es10.3, 12x, f8.3)
 1002 format(1x,"edge/SOL:   ", es10.3, 12x, f8.3)
  call set_core_plasma(ncore / 1.d6, Tcore)
  call set_edge_plasma(nedge / 1.d6, Tedge)



  ! initialize sampling of surface sources
  if (.not.results_initialized) call ERROR("recycling is not initialized")
  recycling = distribution(results%values(1,:) * results%values(2,:), nparticles)


  ! initialize tallies for neutral particle incidents
  if (allocated(summary)) deallocate(summary)
  emin_fast = 10.d0
  allocate (summary(3, nsurfaces), source = 0.d0)
  n0_results = dataset(5, pfc_mesh, CELL_DATA, kind="particle_exhaust")
  call n0_results%annotations%set("firefly_version", version)
  call n0_results%set_parameter("ncode", ncore)
  call n0_results%set_parameter("Tcode", Tcore)
  call n0_results%set_parameter("nedge", nedge)
  call n0_results%set_parameter("Tedge", Tedge)
  call n0_results%set_parameter("nparticles", nparticles)
  call n0_results%set_metadata(1, "atm_incidents", "Atom incidents / recycling")
  call n0_results%set_metadata(2, "mol_incidents", "Molecule incidents / recycling")
  call n0_results%set_metadata(3, "atm_load", "Atom energy load / recycling", "eV * m**(-2)")
  call n0_results%set_metadata(4, "mol_load", "Molecule energy load / recycling", "eV * m**(-2)")
  call n0_results%set_metadata(5, "area", "Surface area per cell", "m**2")
  n0_results%values(5,:) = pfc_mesh%cell_area()


  ! use EIRENE package for particle tracing
  call cpu_time(t1)
  sp = 0.d0
#if WITH_EIRENE
  call progress_bar(0, nparticles / nproc)
  call EIRENE_EIRENE(0.d0, .false., .false., icall_eirene, .false.)
  call finalize_progress_bar()
#else
  call ERROR("EIRENE support is not available")
#endif
  icall_eirene = icall_eirene + 1
  call cpu_time(t2)



  sp_core = sp(1)
  pumped = 1.d0 - sum(sp)
  lost = lost_particles
  call proc(0)%broadcast(lost)
  if (report) then
     print *, "... done"
     print *
     print *, "Ionization in core: ", sp_core
     print *, "Pumping:            ", pumped
     if (lost > 0.d0) print *, "Lost particles:     ", lost
     print *, "Flux of neutrals onto surfaces:        slow atoms      fast atoms      molecules"
     do isurf=1,nsurfaces
        print 2001, isurf-1, pfc_mesh%refined_tpzmesh3d(isurf)%title(), summary(:, isurf)
     enddo
     print *
     print *, "computation time: ", t2 - t1, " s"
     print *
     print *
  endif
  if (rank == 0) call n0_results%savenc(output)
 2001 format(i4,1x,a32,3(4x,e12.5))

  end subroutine particle_exhaust_proxy
  !-----------------------------------------------------------------------------

end module firefly_tasks
