#!/bin/bash
set -eu
export LD_LIBRARY_PATH=/audit/$1:/work/install/lib:/usr/local/lib
mpirun --allow-run-as-root --oversubscribe --bind-to none -np 4 python3 /audit/native.py "$@"
