#!/bin/bash
set -eu
scratch=/mnt/d/DivertorOptimization/studies/nf-source-domain-audit-20261111/native
repo=/mnt/d/DivertorOptimization/worktrees/d3d-report-correction-20261104/verification
study=/mnt/d/DivertorOptimization/studies/nf-stage5-firefly-20261110-r2
if [ "${AUDIT_NS:-0}" != 1 ]; then
 exec unshare --mount --propagation private env AUDIT_NS=1 bash "$0" "$@"
fi
export STAGE5_PRIVATE_NS=1
bash "$repo/stage5_native_enter.sh" "$study" "$repo" true
r=/mnt/firefly20261105/bundle/rootfs
mkdir -p "$r/audit"
mount --bind "$scratch" "$r/audit"
exec bash "$repo/stage5_native_enter.sh" "$study" "$repo" "$@"
