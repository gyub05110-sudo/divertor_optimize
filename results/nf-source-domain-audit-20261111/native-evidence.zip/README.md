# Native source/domain diagnostic

This is a local mechanism audit of **case 3264fdd71f, floor-only candidate wall 892b5e0939244002c986d16aa445f123f3f2ee3eeb024fbe63a125ceff5ef10c, seed 51031**. It is not the baseline wall, a new optimization campaign, or a replacement for the sealed Stage 5 results.

The authoritative runnable source is `instrumented_all/tasks.f90`, `instrumented_all/tracing.f90`, `native.py`, `build_all.py`, `enter.sh`, and `run.sh`. The `prepare*.py` and `finish_instrumentation.py` files are development generators retained for transparency; **do not rerun those generators** over the final source. They precede small runtime/bootstrap corrections. Initial failed and interrupted launches are preserved separately and do not supply the final statistics.

## Reproduce

From Windows, run:

```powershell
wsl -d Ubuntu -u root -- bash /mnt/d/DivertorOptimization/studies/nf-source-domain-audit-20261111/native/enter.sh python3 /audit/build_all.py instrumented_all
wsl -d Ubuntu -u root -- bash /mnt/d/DivertorOptimization/studies/nf-source-domain-audit-20261111/native/enter.sh bash /audit/run.sh instrumented_all 3264fdd71f 892b5e0939244002c986d16aa445f123f3f2ee3eeb024fbe63a125ceff5ef10c 51031
python D:\DivertorOptimization\studies\nf-source-domain-audit-20261111\native\analyze.py
```

The retained runtime is entered in a private mount namespace. The sealed r2 input tree is bound at `/stage5`; only the sibling scratch is written at `/audit`. The driver asserts that the mapped FIREFLY library is `/audit/instrumented_all/libFIREFLY.so`. It uses the sealed mesh, physical wall plus reflecting midplane, and OMP source without edits, four MPI ranks, 4096 total histories, seed 51031, chi=0.45 m2/s, n0=1e19 m-3, T0=100 eV, original tau and 0.2 s physical history cutoff. The native equilibrium query initializes the diagnostic convenience pointer before `geometry.init_workspace` resets the random seed.

## Instrumentation

`tasks.f90` is the corrected cap-sync thermal routine with diagnostic scalar accumulators and one output row per history. It adds no random draw and does not modify a transported coordinate, particle weight, transport parameter, or heat tally. To count the otherwise hidden negative-torosf-map clamp, `tracing.f90` contains the original FLARE `bstep` routine and its `istat_side` helper in a separate `audit_tracing` module, plus one counter increment. The heat routine calls that copy. This is accepted only after byte equality of every native `hload` and `area` value against the published raw seed file. `summary.json` and `receipts.json` record the result and file hashes.

Observed histories contain cumulative deposition to the physical inner mask (R<=1.1645 m, Z<=-1.15 m), deposition elsewhere, first physical wall encounter and increment type, explicit cross-field inner-boundary clamp count, hidden toroidal-map clamp count, first clamp steps, and inner-mask deposition before either clamp. Midplane reflection events are separate from physical wall encounters. The analyzer reconciles this mask with the published native sloped segment 69 and the selected lower part of vertical segment 70; it does not silently call both segments `imp_sloped`.

The case-specific lower X point is (R,Z)=(1.3907611897953485,-1.070269770906762) m and midplane is Z=0.016885746270418167 m. Corner-flux interpolation screens potential psiN<1 visits; each recorded core-side (Z>Z_X) or private-flux-side (Z<Z_X) visit is confirmed by the native equilibrium psiN at the actual RZ coordinate. Thus recorded visits are positive witnesses. Absence of a recorded visit is not a rigorous proof that a continuous trajectory never entered that region. First observed crossing times can lag an exact separatrix crossing. Maximum Z is recorded at each cross-field completion and each parallel-routine return, not every internal toroidal subsegment. No extra parameter control is represented as equivalent physics.

## Boundaries in the audited thermal algorithm

1. The full physical wall receives heat. Cross-field material impact deposits remaining weight and ends the history. Parallel material encounters apply the sheath loading probability, then reflect surviving weight; low-weight histories use the original roulette.
2. The full-R horizontal midplane is a zero-flux cut. Transverse increments through it are rejected and residual parallel displacement is reversed. The corrected inner clamp synchronizes the tracked physical point.
3. The magnetic mesh inner side is a reflecting clamp (`ISB_TAG=7`), not the separatrix. The mesh generator starts at OMP R=2.1927754497581149 m, 80 mm inside the case OMP separatrix R=2.272775449758115 m; the retained domain therefore contains a closed-flux-side layer.
4. Negative toroidal-map correction status is separately clamped inside native `bstep`; both this and the explicit ISB handler are counted in the final diagnostic.
5. Other cross-field or parallel mapping failures leave the simulated mesh and enter the loss ledger. Physical-history and repeated-reflection limits enter the censored ledger. Toroidal symmetry is 64.

There is no radial IMP/OMP separator, absorbing separatrix, or restriction that an OMP-launched history may load only OMP-designated wall. Source selection and receiver-domain restriction are separate questions. The diagnostic establishes pathways present in this implementation, not the physical validity of an artificial boundary choice or a causal sensitivity to moving that boundary.
