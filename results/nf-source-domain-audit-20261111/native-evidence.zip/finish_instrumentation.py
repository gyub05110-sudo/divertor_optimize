from pathlib import Path
p=Path(__file__).parent/'instrumented_all/tasks.f90'
s=p.read_text()
s=s.replace('  integer :: du, de, dhit,','  integer :: disbstep, dtmapstep\n  real(real64) :: dpreboth\n  integer :: du, de, dhit,')
s=s.replace('     diagnostic_tmap_clamps=0','     disbstep=0;dtmapstep=0;dpreboth=0.d0\n     diagnostic_tmap_clamps=0')
s=s.replace('           disb=disb+1','           if(disbstep==0) disbstep=nstep\n           disb=disb+1')
s=s.replace('           call diagnostic_position()', '           if(dtmapstep==0.and.diagnostic_tmap_clamps>0) dtmapstep=nstep\n           call diagnostic_position()')
s=s.replace(' pfr_R pfr_Z tmap_clamps"',' pfr_R pfr_Z tmap_clamps first_ISB_step first_tmap_step imp_before_both"')
s=s.replace('dpfrrz,diagnostic_tmap_clamps\n','dpfrrz,diagnostic_tmap_clamps,disbstep,dtmapstep,dpreboth\n')
s=s.replace('  if(region==1.and.disb==0) dpreisb=dpreisb+dw','  if(region==1.and.disb==0) dpreisb=dpreisb+dw\n  if(region==1.and.disb==0.and.diagnostic_tmap_clamps==0) dpreboth=dpreboth+dw')
p.write_text(s,newline='\n')
