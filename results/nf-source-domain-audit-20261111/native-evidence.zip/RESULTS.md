# Verified local route diagnosis

The final four-rank, 4096-history, seed-51031 diagnostic reproduces the **entire published native.nc byte for byte** (SHA256 `da27c28554fc153ce574469dd83a8a5539b6c8e4c6f2474820f1c3d3fdceb4a5`). The case is 3264fdd71f and wall 892b5e… is the **floor-only candidate**, not the baseline. No sealed file was edited.

This seed deposits **116,271.623 W on original sloped segment 69**, zero on the selected vertical segment 70, and 1,000,000 W on the whole material wall. This is one seed; it must not be presented as the approximately 98 kW pooled result. The event-based inner-mask sum reconciles with native sloped power to floating-point roundoff, so the history attribution below is exact for this run's sloped deposition.

| History grouping | Histories | Sloped deposition from these histories, W |
|---|---:|---:|
| All histories contributing to IMP sloped | 1,426 | 116,271.623 |
| First physical wall encounter on IMP | 130 | 20,995.448 |
| First physical wall encounter elsewhere, then IMP | 1,296 | 95,276.175 |
| Confirmed core-side visit before first IMP encounter | 1,389 | 113,623.511 |
| Confirmed PFR-side visit before first IMP encounter | 487 | 33,131.743 |
| Confirmed PFR before IMP, without a confirmed earlier core visit | 37 | 2,648.112 |
| Never touched either artificial clamp | 1,385 | 113,480.391 |
| Touched either artificial clamp at some time | 41 | 2,791.232 |

Core and PFR rows overlap. Region visits are confirmed positive observations, screened as described in README; absence is not a proof about the continuous path. Of the 41 clamp-associated IMP histories, 23 encountered a clamp before their first IMP encounter. Event-by-event, **114,098.821 W** of sloped deposition occurred before either first clamp; **2,172.802 W** occurred after a clamp. Association with a clamp is not the counterfactual effect of moving/removing that boundary.

The run recorded 67,773 explicit cross-field ISB clamp events and 118,752 hidden toroidal-map clamp events, across all histories. There were 871,809 physical wall encounters. First encounters were parallel in 4,093 histories and cross-field in three. Initial IMP-contact deposition itself was only 433.749 W; the remaining load accumulates over subsequent transport and partial absorption/reflection events.

The domain contains a substantial closed-flux-side layer: the inner mesh start at OMP R=2.19277545 m has **psiN=0.80933617**, whereas the OMP separatrix is R=2.27277545 m. The separatrix is not an absorbing or reflecting barrier. The code reflects at the deeper mesh boundary and at the horizontal midplane; it does not insert an IMP/OMP partition within the lower domain.

One explicit witness is history 1. It enters the core side at step 44 at (R,Z)=(2.24692206,-0.15690493) m, where exact native psiN=0.99981852. It first reaches R<=R_X at step 105 with Z=-1.05659955 m, above the lower X-point Z=-1.07026977 m but far below the midplane. Its first physical wall encounter is IMP at step 5375. It never touches either artificial clamp. A later PFR visit occurs at step 5616. History 15 instead records a PFR-side visit before its first IMP encounter. The full witness rows and flux queries are retained in `summary.json` and `flux-witnesses.json`.

No recorded cross-field completion or parallel-routine return exceeds the midplane (even at 1 nm tolerance); the maximum Z equals 0.016885746270418167 m. This observation does not inspect every internal toroidal subsegment. The sealed wall tally independently has zero above-midplane deposition.

Direct-field-line statements require their boundary/direction qualifier. In the sealed open-PFC trace, the positive, selected lower-directed branch reaches IMP for **0/1280 donors**; the unrestricted negative branch reaches IMP for **982/1280**. That open trace has no reflecting midplane. The capped heat calculation permits cross-field separatrix crossing and repeated wall interactions below the midplane, so its IMP heat is not evidence that the source file mixed IMP donors or that the corrected cap failed.

These observations establish the mechanism and the implemented domain for one unchanged native run. They do not establish equivalence with a reduced receiver-space model, prescribe a physical IMP/OMP barrier, or measure sensitivity to the location of the artificial inner boundary.
