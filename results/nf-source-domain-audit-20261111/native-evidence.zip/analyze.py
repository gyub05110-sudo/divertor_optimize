from pathlib import Path
import json,hashlib,difflib
import numpy as np
import h5py
root=Path(__file__).parent
study=root.parent.parent/'nf-stage5-firefly-20261110-r2'
case='3264fdd71f';wall='892b5e0939244002c986d16aa445f123f3f2ee3eeb024fbe63a125ceff5ef10c'
dest=root/'instrumented_all'/f'{case}_{wall[:10]}_51031'
raw=study/'native/results'/case/wall/'51031.nc'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
with h5py.File(raw) as a,h5py.File(dest/'native.nc') as b:
 checks={k:a[k][:].tobytes()==b[k][:].tobytes() for k in ('hload','area')}
 assert all(checks.values()),checks
 p=a['grid/domain/wall/x'][:,0,:]; mid=(p[:-1]+p[1:])/2
 n=(len(p)-1)*3; w=(a['hload'][:n]*a['area'][:n]).reshape(-1,3).sum(axis=1)*64e6
 imp=(mid[:,0]<=1.1645+1e-7)&(mid[:,1]<=-1.15+1e-7)
 slope=imp&(mid[:,1]<=-1.217+1e-7)
 published=dict(imp_total_W=float(w[imp].sum()),imp_sloped_W=float(w[slope].sum()),imp_vertical_W=float(w[imp&~slope].sum()),wall_W=float(w.sum()))
 cut=float(a['grid/domain/reflect_midplane/x'][0,0,1])
files=sorted(dest.glob('history-rank*.txt'))
cols=files[0].read_text().splitlines()[0].lstrip('# ').split()
arr=np.concatenate([np.loadtxt(f,ndmin=2) for f in files]);arr=arr[np.argsort(arr[:,0])]
assert arr.shape==(4096,len(cols)),(arr.shape,len(cols))
assert np.array_equal(arr[:,0],np.arange(1,4097))
d=dict(zip(cols,arr.T));W=d['imp_weight']*64e6;hit=W>0
assert np.isclose(W.sum(),published['imp_total_W'],rtol=0,atol=1e-6),(W.sum(),published)
def subset(mask): return dict(histories=int(mask.sum()),IMP_deposit_W=float(W[mask].sum()))
core=(d['core_step']>0)&(d['core_step']<=d['imp_step'])
pfr=(d['pfr_step']>0)&(d['pfr_step']<=d['imp_step'])
isb=d['ISB']>0;tmap=d['tmap_clamps']>0;anyb=isb|tmap
before=((d['first_ISB_step']>0)&(d['first_ISB_step']<=d['imp_step']))|((d['first_tmap_step']>0)&(d['first_tmap_step']<=d['imp_step']))
result=dict(case_id=case,role='floor-only',wall_id=wall,seed=51031,histories=4096,ranks=4,
 tally_byte_identity=checks,published_raw_sha256=sha(raw),diagnostic_raw_sha256=sha(dest/'native.nc'),
 library_sha256=sha(root/'instrumented_all/libFIREFLY.so'),published=published,
 categories={
 'all_IMP_histories':subset(hit),'first_physical_hit_IMP':subset(hit&(d['first_region']==1)),
 'first_physical_hit_elsewhere_then_IMP':subset(hit&(d['first_region']==2)),
 'core_before_first_IMP':subset(hit&core),'PFR_before_first_IMP':subset(hit&pfr),
 'core_but_not_PFR_before_first_IMP':subset(hit&core&~pfr),
 'PFR_but_not_core_before_first_IMP':subset(hit&pfr&~core),
 'both_core_and_PFR_before_first_IMP':subset(hit&core&pfr),
 'first_observed_Rx_crossing_above_X':subset(hit&(d['cross']>0)&(d['crossing_Z']>-1.070269770906762)),
 'first_observed_Rx_crossing_below_X':subset(hit&(d['cross']>0)&(d['crossing_Z']<=-1.070269770906762)),
 'explicit_ISB_ever':subset(hit&isb),'hidden_tmap_clamp_ever':subset(hit&tmap),
 'any_artificial_clamp_ever':subset(hit&anyb),'never_artificial_clamp':subset(hit&~anyb),
 'artificial_clamp_before_first_IMP':subset(hit&before)},
 IMP_W_deposited_before_first_explicit_ISB=float(d['imp_before_ISB'].sum()*64e6),
 IMP_W_deposited_before_either_artificial_clamp=float(d['imp_before_both'].sum()*64e6),
 max_sampled_Z_m=float(d['max_Z'].max()),midplane_Z_m=cut,
 histories_above_midplane_1nm=int((d['max_Z']>cut+1e-9).sum()),
 total_explicit_ISB_events=int(d['ISB'].sum()),total_hidden_tmap_clamps=int(d['tmap_clamps'].sum()),
 total_wall_events=int(d['wall_hits'].sum()),first_wall_hit_counts={str(k):int((d['first_region']==k).sum()) for k in (1,2)},
 first_wall_step_kind_counts={'cross_field':int((d['first_kind']==1).sum()),'parallel':int((d['first_kind']==2).sum())},
 first_physical_IMP_contact_deposition_W=float((d['first_load']*(d['first_region']==1)).sum()*64e6),
 notes=['Original source and native transport parameters retained; no random numbers added.',
 'IMP criterion physical R<=1.1645m and Z<=-1.15m includes sloped segment69 and lower segment70; published native wall geometry provides exact sloped/vertical reconciliation.',
 'Core/PFR flags require exact native psiN<1 confirmation at RZ, with Z above/below lower X point. Bilinear corner-flux screening can delay detection; first-step counters are observed entry times, not mathematically exact separatrix crossing times.',
 'Max Z observed after transverse steps and each bstep return, not at every internal toroidal subsegment.',
 'Explicit ISB and hidden torosf_map clamp events are both counted; weight-before-clamp is event-exact.',
 'Attribution to histories that ever visited a region is associative; no changed-boundary causal control performed.'])
trace_path=study/'native/cases'/case/(wall+'.strikes.dat')
tr=np.loadtxt(trace_path)
result['open_PFC_direct_trace']={
 'file_sha256':sha(trace_path),'donors':len(tr),'failures':int((tr[:,2]!=0).sum()),
 'negative_direction_inner_hits':int(((tr[:,3]>0)&(tr[:,3]<=1.1645)&(tr[:,4]<=-1.15)).sum()),
 'positive_lower_direction_inner_hits':int(((tr[:,5]>0)&(tr[:,5]<=1.1645)&(tr[:,6]<=-1.15)).sum()),
 'note':'The published direct trace uses open PFC without the reflecting cap. Negative-direction connections are not the capped lower-leg experiment. The positive lower-directed donor path has zero inner hits.'}
witness_ids=[1]
for mask in (hit&~anyb&core&~pfr,hit&~anyb&pfr&~core,hit&anyb):
 if mask.any(): witness_ids.append(int(d['i'][np.flatnonzero(mask)[0]]))
result['witnesses']=[{k:float(arr[i-1,j]) for j,k in enumerate(cols)} for i in sorted(set(witness_ids))]
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
original=study/'native-physics/cap-sync-v1/tasks.f90'
if not original.exists(): original=study/'native-physics/repair-controls/synchronized/tasks.f90'
if not original.exists(): original=root.parent.parent/'nf-stage5-firefly-cap-repair-20261110/synchronized/tasks.f90'
if original.exists():
 (root/'tasks-diagnostic.patch').write_text(''.join(difflib.unified_diff(original.read_text().splitlines(True),(root/'instrumented_all/tasks.f90').read_text().splitlines(True),fromfile=str(original),tofile='instrumented_all/tasks.f90')))
(root/'receipts.json').write_text(json.dumps({str(p.relative_to(root)):sha(p) for p in [root/'instrumented_all/tasks.f90',root/'instrumented_all/tracing.f90',root/'instrumented_all/libFIREFLY.so',root/'native.py',root/'enter.sh',root/'build_all.py',*files]},indent=2)+'\n')
print(json.dumps(result,indent=2))
