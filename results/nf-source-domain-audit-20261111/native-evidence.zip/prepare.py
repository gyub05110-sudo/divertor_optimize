from pathlib import Path
root=Path(__file__).parent
old=Path('D:/DivertorOptimization/studies/nf-stage5-firefly-cap-repair-20261110')
s=(old/'synchronized/tasks.f90').read_text()
p,b=s.split('  subroutine heat_load_proxy(',1); b,t=b.split('  end subroutine heat_load_proxy',1)
def rep(a,c):
 global b
 assert b.count(a)==1,(a,b.count(a)); b=b.replace(a,c)
rep('  use moose_mpi','  use flare_model, only: equi2d\n  use moose_mpi')
rep('  real(real64) :: psrc(3)', '''  integer :: du, de, dhit, disb, dcapx, dcapb, dfirst, dfirststep, dfirstkind, dimpstep
  integer :: dcross, dcore, dpfr, dj, dk, dit, dkind, dcorestep, dpfrstep
  real(real64) :: dpower(2), dpreisb, dfirstload, dq(2), dqprev(2), dmaxz, dminz, dminr
  real(real64) :: dpsi, dpsimin, dpc(4), dxi(2), dcrossz, dcorerz(2), dpfrrz(2)
  real(real64), allocatable :: dflux(:,:)
  character(len=80) :: dfile
  real(real64) :: psrc(3)''')
rep('  call progress_bar(0, nparticles)', '''  write(dfile,'("history-rank",i1,".txt")') rank
  open(newunit=du,file=trim(dfile),status="replace")
  write(du,'(a)') "# i steps first_region first_step first_kind wall_hits ISB cap_x cap_b core pfr cross core_step pfr_step imp_step " // &
    "imp_weight other_weight imp_before_ISB first_load max_Z min_Z min_R min_psi_interp crossing_Z core_R core_Z pfr_R pfr_Z"
  allocate(dflux(4,0:mesh%ntubes-1))
  do dit=0,mesh%ntubes-1
     do dj=1,4
        dq=mesh%rzcoords(mesh%corner(dj,dit),mesh%lbound_tube(dit))
        dflux(dj,dit)=equi2d%psiN(dq)
     enddo
  enddo
  call progress_bar(0, nparticles)''')
rep('     nstep=0', '''     dhit=0;disb=0;dcapx=0;dcapb=0;dfirst=0;dfirststep=0;dfirstkind=0;dimpstep=0
     dcross=0;dcore=0;dpfr=0;dcorestep=0;dpfrstep=0
     dpower=0.d0;dpreisb=0.d0;dfirstload=0.d0;dcrossz=99.d0;dcorerz=99.d0;dpfrrz=99.d0
     dqprev=psrc(1:2);dmaxz=psrc(2);dminz=psrc(2);dminr=psrc(1);dpsimin=99.d0
     nstep=0''')
rep('              c=before_x', '              dcapx=dcapx+1\n              c=before_x')
rep('           D%values(1,icell) = D%values(1,icell) + w\n', '''           call diagnostic_wall(w,1)
           D%values(1,icell) = D%values(1,icell) + w\n''')
rep('           c%xi(2) = -0.9999876543210d0','           disb=disb+1\n           c%xi(2) = -0.9999876543210d0')
rep('        ! 2. step along field line','        call diagnostic_position()\n\n        ! 2. step along field line')
rep('           ! - finished bstep', '           call diagnostic_position()\n           ! - finished bstep')
rep('                 ds=-ds', '                 dcapb=dcapb+1\n                 ds=-ds')
rep('              if (wload > 0.d0) then', '''              ! Diagnostic records zero-load encounters as real first impacts too.
              call diagnostic_wall(wload,2)
              if (wload > 0.d0) then''')
rep('     call progress_bar(i, nparticles)', '''     write(du,*) i,nstep,dfirst,dfirststep,dfirstkind,dhit,disb,dcapx,dcapb,dcore,dpfr,dcross, &
       dcorestep,dpfrstep,dimpstep,dpower,dpreisb,dfirstload,dmaxz,dminz,dminr,dpsimin,dcrossz,dcorerz,dpfrrz
     flush(du)
     call progress_bar(i, nparticles)''')
rep('  call finalize_progress_bar()', '  close(du)\n  deallocate(dflux)\n  call finalize_progress_bar()')
rep('  end associate', '''  end associate
  contains
  subroutine diagnostic_wall(dw,kind)
  real(real64), intent(in) :: dw
  integer, intent(in) :: kind
  integer :: region
  ! Physical original segments 69 and lower segment 70; exact receiver mask used in analysis.
  region=2
  if(c%p(1)<=1.1645d0+1.d-7.and.c%p(2)<=-1.15d0+1.d-7) region=1
  dhit=dhit+1
  if(dhit==1) then
     dfirst=region;dfirststep=nstep;dfirstkind=kind;dfirstload=dw
  endif
  if(region==1.and.dimpstep==0) dimpstep=nstep
  dpower(region)=dpower(region)+dw
  if(region==1.and.disb==0) dpreisb=dpreisb+dw
  end subroutine
  subroutine diagnostic_position()
  real(real64) :: q(2), v, a,b,zz
  q=mesh%rzcoords(c%mcoords)
  dmaxz=max(dmaxz,q(2));dminz=min(dminz,q(2));dminr=min(dminr,q(1))
  if(dcross==0.and.dqprev(1)>1.3907611897953485d0.and.q(1)<=1.3907611897953485d0) then
    dcross=nstep
    dcrossz=q(2)
  endif
  dqprev=q
  a=(c%xi(1)+1.d0)/2.d0;b=(c%xi(2)+1.d0)/2.d0
  ! Quad corner order verified against moose kvert: (-1,-1),(1,-1),(1,1),(-1,1).
  v=(1-a)*(1-b)*dflux(1,c%itube)+a*(1-b)*dflux(2,c%itube) &
    +a*b*dflux(3,c%itube)+(1-a)*b*dflux(4,c%itube)
  dpsimin=min(dpsimin,v)
  if(v<1.d0) then
    if(dcore==0.and.q(2)>-1.070269770906762d0) then
      if(equi2d%psiN(q)<1.d0) then
        dcore=1;dcorestep=nstep;dcorerz=q
      endif
    endif
    if(dpfr==0.and.q(2)<-1.070269770906762d0) then
      if(equi2d%psiN(q)<1.d0) then
        dpfr=1;dpfrstep=nstep;dpfrrz=q
      endif
    endif
  endif
  end subroutine''')
(root/'instrumented').mkdir(exist_ok=True)
(root/'instrumented/tasks.f90').write_text(p+'  subroutine heat_load_proxy('+b+'  end subroutine heat_load_proxy'+t,newline='\n')
build=(old/'build.py').read_text().replace('Path("/repair")','Path("/audit")')
(root/'build.py').write_text(build,newline='\n')
native=(old/'native.py').read_text().replace('"/repair"','"/audit"').replace('"/repair/"','"/audit/"')
native=native.replace('geometry.init_workspace(str(mesh),seed=seed);', 'from flare import model\nmodel.load(str(mesh.parent.parent/"model"))\ngeometry.init_workspace(str(mesh),seed=seed);')
(root/'native.py').write_text(native,newline='\n')
(root/'enter.sh').write_text('''#!/bin/bash
set -eu
scratch=/mnt/d/DivertorOptimization/studies/nf-source-domain-audit-20261111/native
repo=/mnt/d/DivertorOptimization/worktrees/d3d-report-correction-20261104/verification
study=/mnt/d/DivertorOptimization/studies/nf-stage5-firefly-20261110-r2
if [ "${AUDIT_NS:-0}" != 1 ]; then
 exec unshare --mount --propagation private env AUDIT_NS=1 bash "$0" "$@"
fi
bash "$repo/stage5_native_enter.sh" "$study" "$repo" true
r=/mnt/firefly20261105/bundle/rootfs
mkdir -p "$r/audit"
mount --bind "$scratch" "$r/audit"
exec bash "$repo/stage5_native_enter.sh" "$study" "$repo" "$@"
''',newline='\n')
(root/'run.sh').write_text('''#!/bin/bash
set -eu
export LD_LIBRARY_PATH=/audit/$1:/work/install/lib:/usr/local/lib
mpirun --allow-run-as-root --oversubscribe --bind-to none -np 4 python3 /audit/native.py "$@"
''',newline='\n')
