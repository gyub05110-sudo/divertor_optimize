from pathlib import Path
import json,hashlib,difflib
r=Path(__file__).parent
original=r.parent.parent/'nf-stage5-firefly-cap-repair-20261110/synchronized/tasks.f90'
(r/'tasks-diagnostic.patch').write_text(''.join(difflib.unified_diff(original.read_text().splitlines(True),(r/'instrumented_all/tasks.f90').read_text().splitlines(True),fromfile=str(original),tofile='instrumented_all/tasks.f90')))
provenance=json.loads((r/'provenance.json').read_text())
provenance['corrected_source']={'path':str(original),'sha256':hashlib.sha256(original.read_bytes()).hexdigest()}
(r/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
names=['README.md','RESULTS.md','summary.json','receipts.json','provenance.json','flux-witnesses.json','flux-probe.log','probe.py','native.py','build_all.py','enter.sh','run.sh','build_and_run.sh','analyze.py','freeze_manifest.py','tasks-diagnostic.patch','tracing-diagnostic.patch','instrumented_all/tasks.f90','instrumented_all/tracing.f90','instrumented_all/libFIREFLY.so','instrumented_all.log','initial-diagnostic-failure.log','diagnostic-link-failure.log','prepare.py','prepare_all.py','finish_instrumentation.py']
d='instrumented_all/3264fdd71f_892b5e0939_51031/'
names +=[d+x for x in ['history-rank0.txt','history-rank1.txt','history-rank2.txt','history-rank3.txt','native.nc','timing.json']]
a=[dict(path=n,bytes=(r/n).stat().st_size,sha256=hashlib.sha256((r/n).read_bytes()).hexdigest())for n in names]
(r/'evidence-files.json').write_text(json.dumps(a,indent=2)+'\n')
print(len(a),'files',sum(x['bytes'] for x in a),'bytes')
