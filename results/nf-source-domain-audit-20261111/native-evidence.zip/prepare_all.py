from pathlib import Path
root=Path(__file__).parent
var=root/'instrumented_all';var.mkdir(exist_ok=True)
base=root/'instrumented/tasks.f90'
s=base.read_text().replace('dhit=0;disb=0;','diagnostic_tmap_clamps=0\n     dhit=0;disb=0;')
s=s.replace('  use flare_model, only: equi2d','  use audit_tracing, only: audit_bstep, diagnostic_tmap_clamps\n  use flare_model, only: equi2d')
s=s.replace('call tracing%bstep(c, ds, istat, n, u)','call audit_bstep(tracing,c,ds,istat,n,u)')
s=s.replace('"imp_weight other_weight', '"imp_weight other_weight')
s=s.replace('core_R core_Z pfr_R pfr_Z"','core_R core_Z pfr_R pfr_Z tmap_clamps"')
s=s.replace('dcrossz,dcorerz,dpfrrz\n','dcrossz,dcorerz,dpfrrz,diagnostic_tmap_clamps\n')
(var/'tasks.f90').write_text(s,newline='\n')
trace=Path('D:/DivertorOptimization/studies/firefly-baseline-20261105/flare/src/fortran/mmesh/unstructured/tracing.f90').read_text()
trace=trace[trace.index('  subroutine bstep('):trace.index('  end function istat_side')+len('  end function istat_side')]
trace=trace.replace('subroutine bstep','subroutine audit_bstep')
trace='''module audit_tracing
use iso_fortran_env
use flare_mmesh_unstructured_tracing
use flare_mmesh_unstructured_mmesh
implicit none
integer :: diagnostic_tmap_clamps=0
integer, parameter :: max_bsteps=1024
contains
'''+trace+'\nend module audit_tracing\n'
trace=trace.replace('     if (istat < 0) then','     if (istat < 0) then\n         diagnostic_tmap_clamps=diagnostic_tmap_clamps+1')
(var/'tracing.f90').write_text(trace,newline='\n')
b=(root/'build.py').read_text()
b=b.replace('print(shlex.join(cmd),flush=True)', '''tracecmd=cmd.copy();tracecmd[tracecmd.index("tasks.f90")]="tracing.f90";tracecmd[-1]="diagnostic_tracing.f90.o"
print(shlex.join(tracecmd),flush=True)
subprocess.run(tracecmd,check=True)
print(shlex.join(cmd),flush=True)''',1)
b=b.replace('print(shlex.join(args),flush=True)', 'args.insert(args.index("tasks.f90.o"),"diagnostic_tracing.f90.o")\nprint(shlex.join(args),flush=True)')
(root/'build_all.py').write_text(b,newline='\n')
