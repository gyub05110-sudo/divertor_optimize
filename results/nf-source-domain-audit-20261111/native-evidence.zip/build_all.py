from pathlib import Path
import sys, subprocess, shlex, os
root=Path("/audit")
var=root/sys.argv[1];var.mkdir(exist_ok=True)
os.chdir(var)
build=Path("/tmp/firefly-build/src/fortran/CMakeFiles/FIREFLY.dir")
flags=(build/"flags.make").read_text()
includes=shlex.split(next(l for l in flags.splitlines() if l.startswith("Fortran_INCLUDES")).split("=",1)[1])
cmd=["gfortran","-cpp","-DFIREFLY_EXPORTS","-O3","-fPIC","-J.",*includes,"-c","tasks.f90","-o","tasks.f90.o"]
tracecmd=cmd.copy();tracecmd[tracecmd.index("tasks.f90")]="tracing.f90";tracecmd[-1]="diagnostic_tracing.f90.o"
print(shlex.join(tracecmd),flush=True)
subprocess.run(tracecmd,check=True)
print(shlex.join(cmd),flush=True)
subprocess.run(cmd,check=True)
args=shlex.split((build/"link.txt").read_text())
args=[x for x in args if not x.startswith("-Wl,--dependency-file")]
args=[str(build/Path(x).name) if x.startswith("CMakeFiles") and not x.endswith("tasks.f90.o") else ("tasks.f90.o" if x.endswith("tasks.f90.o") else x) for x in args]
args.insert(args.index("tasks.f90.o"),"diagnostic_tracing.f90.o")
print(shlex.join(args),flush=True)
subprocess.run(args,check=True)
