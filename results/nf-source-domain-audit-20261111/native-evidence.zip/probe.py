from pathlib import Path
import json,numpy as np,hashlib
from flare import model
from flare.analysis import equi2d
base=Path('/stage5/native/cases/3264fdd71f')
model.load(str(base/'model'))
dest=Path('/audit/instrumented_all/3264fdd71f_892b5e0939_51031')
files=sorted(dest.glob('history-rank*.txt'))
cols=files[0].read_text().splitlines()[0].lstrip('# ').split()
rows=np.concatenate([np.loadtxt(f,ndmin=2)for f in files]);one=rows[rows[:,0]==1][0];d=dict(zip(cols,one))
points={'inner_mesh_OMP_start':[2.1927754497581149,0.016885746270418167],
 'OMP_separatrix':[2.272775449758115,0.016885746270418167],
 'history1_confirmed_core':[d['core_R'],d['core_Z']],
 'history1_confirmed_PFR':[d['pfr_R'],d['pfr_Z']]}
answer={k:{'RZ_m':v,'psiN':float(equi2d.psiN(*v))} for k,v in points.items()}
answer['equilibrium_sha256']=hashlib.sha256((base/'model/fixed.geqdsk').read_bytes()).hexdigest()
Path('/audit/flux-witnesses.json').write_text(json.dumps(answer,indent=2)+'\n')
print(json.dumps(answer,indent=2))
