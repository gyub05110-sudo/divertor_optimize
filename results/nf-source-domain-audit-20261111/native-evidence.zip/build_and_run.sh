#!/bin/bash
set -eu
python3 /audit/build_all.py instrumented_all
bash /audit/run.sh instrumented_all 3264fdd71f 892b5e0939244002c986d16aa445f123f3f2ee3eeb024fbe63a125ceff5ef10c 51031
